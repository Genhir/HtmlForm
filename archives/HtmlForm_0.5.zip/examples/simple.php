<?php

require_once( '../HtmlForm.php' );

function valid( HtmlForm $form )
{
  echo <<<HTML
<h1>Forumlaire valid�</h1>
<pre>INSERT users {$form->mysqlSet()} ON DUPLICATE KEY UPDATE {$form->mysqlDuplicateValues()}</pre>

HTML;
  exit;
}

function check_country( HtmlFormElement $element, HtmlForm $form )
{
  if( $element->value == 'FR' )
    return 'FR';
  else
    return false;
}

HtmlOut::display( $form =
HtmlForm::hie('inscription')->setGet()

  ->text('pseudo')->required('Ce champ est obligatoire')->check('/^\w{4,16}$/')
  ->email()->required('Saisissez votre adresse email')
  ->country('pays')->required('Ce champ est obligatoire')->check('check_country')->alert(array(
    true=>'Hack !',
    'FR'=>'Vous ne pouvez pas habiter en france'))->choice('-- choisissez un pays dans la liste --')
    ->submit()->label('Envoyer')->required('Vous devez valider le formulaire')

  ->onValid('valid') );

require_once( '../debug.php' );

debug( $form );

debug( $form->error );

?>
<style>
.error { background: #f99; }
</style>
