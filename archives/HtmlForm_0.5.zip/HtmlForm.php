<?php

/**
 * Operations pour formulaire.
 *
 * Fourni une impl�mentation g�n�rique des diverses op�rations effectu� autour des formulaire HTML.
 * Prend en charge l'affichage des champs, le controle des donn�es et la construction de la requ�te SQL.
 *
 * @author martin mauchauff�e HtmlForm@moechofe.com
 * @version 0.5
 */

/**
 * Classe de formulaire
 */
class HtmlForm implements ArrayAccess, Iterator
{
  // {{{ $name

  /**
   * Le nom de formulaire.
   *
   * Correspond a l'attribut name de la balise form.
   *
   * @var string|null
   */
  private $name = null;

  // }}}
  // {{{ $elements

  /**
   * Liste des elements du formulaire.
   *
   * Contient un tableau dont les clefs sont les noms de balises et les valeurs sont des instances de HtmlFormElement
   *
   * @var array
   */
  private $elements = array();

  // }}}
  // {{{ $current

  /**
   * Un pointeur sur le dernier element ajout� dans le formulaire.
   *
   * @var HtmlFormElement
   */
  private $current = null;

  // }}}
  // {{{ $method

  /**
   * La m�thode d'envoie du formulaire.
   *
   * Correpond � l'attribut method de la balise form.
   *
   * @var string
   */
  private $method = 'post';

  // }}}
  // {{{ $valid_callback

  /**
   * Fonction de callback.
   *
   * Le nom d'une fonction de callback � appeler si le formulaire est valide.
   *
   * @var string
   */
  private $valid_callback = false;

  // }}}
  // {{{ __construct()

  /**
   * Contruit un nouveau formulaire.
   *
   * @param string Le nom du formulaire correspond � l'attribut name de la balise form.
   */
  public function __construct( $name )
  {
    if( ! is_string($name) ) throw new InvalidArgumentException;
    if( ! preg_match('/^[_\w-]+$/', $name ) ) throw new InvalidArgumentException;

    $this->name = $name;
  }

  // }}}
  // {{{ __call()

  /**
   * Surcharge des m�thodes.
   *
   * Appel une m�thode setxxxx de l'el�ment pr�cedement ajout�, ou
   * contruit un nouvel object d'un classe HtmlFormxxxxx,
   * o� xxxx est le nom de la m�thode surcharg�.
   *
   * @param string Le nom de la m�thode surcharg�e.
   * @param array Les param�tres pass� � la m�thode.
   * @return HtmlForm
   */
  public function __call( $method, $arguments )
  {
    if( ! is_string($method) ) throw new InvalidArgumentException;
    if( ! is_array($arguments) ) throw new InvalidArgumentException;

    if( $this->current instanceof HtmlFormElement and is_callable( $callback = array($this->current,'set'.ucfirst($method)) ) )
    {
      call_user_func_array( $callback, $arguments );
      return $this;
    }

    if( ! class_exists($class_name = 'HtmlForm'.ucfirst($method)) )
      throw new BadMethodCallException(sprintf('Try to append an unexists element class: %s', $class_name));

    if( ! is_subclass_of($class_name,'HtmlFormElement') )
      throw new BadMethodCallException(sprintf('The element class: %s isn\'t an child of the class: HtmlFormElement', $class_name));

    return $this->appendElement( new $class_name( @$arguments[0] ) );
  }

  // }}}
  // {{{ __get()

  /**
   * Surcharge des propri�t�s.
   *
   * Rend publique les propri�t�s de la class HtmlForm.
   * Renvoie en plus une propri�t� cach� : error
   *
   * @param Le nom de la propri�t�.
   * @return mixed
   */
  public function __get( $property )
  {
    if( ! is_string($property) ) throw new InvalidArgumentException;

    if( $property === 'error' )
    {
      foreach( $this->elements as $element )
        if( $element->error )
          return true;
      return false;
    }

    if( ! isset($this->$property) ) throw new BadPropertyException( sprintf('The property "%s::%s" is undefined',get_class($this),$property) );

    return $this->$property;
  }

  // }}}
  // {{{ hie()

  /**
   * Instancie un nouveau formulaire.
   *
   * @param string Le nom du formulaire correspond � l'attribut name de la balise form.
   * @return HtmlForm
   */
  static public function hie( $name )
  {
    if( ! is_string($name) ) throw new InvalidArgumentException;
    if( ! preg_match('/^[_\w-]+$/', $name ) ) throw new InvalidArgumentException;

    return new self( $name );
  }

  // }}}
  // {{{ appendElement()

  /**
   * Ajout une �l�ment dans le formulaire
   *
   * @param HtmlFormElement
   * @return HtmlForm
   */
  public function appendElement( HtmlFormElement $element )
  {
    $this->current = $element;
    $this->elements[ $element->name ] = $element;
    return $this;
  }

  // }}}
  // {{{ selectElement()

  /***
   * Selectionne un �l�ment
   *
   * @param string Le nom de l'instance de l'�l�ment.
   * @return HtmlForm
   */
  public function selectElement( $name )
  {
    if( ! is_string($name) ) throw new InvalidArgumentException;

    if( ! isset($this->elements[ $name ]) ) throw new OutOfBoundsException;

    $this->current = $this->elements[ $name ];

    return $this;
  }

  // }}}
  // {{{ setPost()

  /**
   * Indique d'envoyer le formulaire en POST
   *
   * @return HtmlForm
   */
  public function setPost()
  {
    $this->method = 'post';
    return $this;
  }

  // }}}
  // {{{ setGet()

  /**
   * Indique d'envoyer le formulaire en GET
   *
   * @return HtmlForm
   */
  public function setGet()
  {
    $this->method = 'get';
    return $this;
  }

  // }}}
  // {{{ current()

  /**
   * @ignore
   */
  public function current()
  {
    return current($this->elements);
  }

  // }}}
  // {{{ next()

  /**
   * @ignore
   */
  public function next()
  {
    return next($this->elements);
  }

  // }}}
  // {{{ key()

  /**
   * @ignore
   */
  public function key()
  {
    return key($this->elements);
  }

  // }}}
  // {{{ rewind()

  /**
   * @ignore
   */
  public function rewind()
  {
    return reset($this->elements);
  }

  // }}}
  // {{{ valid()

  /**
   * @ignore
   */
  public function valid()
  {
    return (bool)current($this->elements);
  }

  // }}}
  // {{{ offsetExists()

  /**
   * @ignore
   */
  public function offsetExists( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    return isset($this->elements[$offset]);
  }

  // }}}
  // {{{ offsetGet()

  /**
   * @ignore
   */
  public function offsetGet( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    if( ! isset($this->elements[$offset]) ) throw new OutOfBoundsException(sprintf('Try to acces to an undefined index: %.',$offset));

    return $this->elements[$offset];
  }

  // }}}
  // {{{ offsetSet()

  /**
   * @ignore
   */
  public function offsetSet( $offset, $value )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;
    if( ! $value instanceof HtmlFormElement ) throw new InvalidArgumentException;

    $this->elements[$offset] = $value;
  }

  // }}}
  // {{{ offsetUnset()

  /**
   * @ignore
   */
  public function offsetUnset( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    if( ! isset($this->elements[$offset]) ) throw new OutOfBoundsException(sprintf('Try to acces to an undefined index: %.',$offset));

    unset( $this->elements[$offset] );
  }

  // }}}
  // {{{ onValid()

  /**
   * Sp�cifie une fonction de callback.
   *
   * Cette fonction sera appel� si le formulaire est valid�.
   *
   * @param string Une fonction de callback valide.
   * @return HtmlForm
   */
  public function onValid( $function )
  {
    if( ! is_callable($function) ) throw new InvalidArgumentException( sprintf('The function "%s" isn\'t callable.',print_r($function,true)) );

    $this->valid_callback = $function;

    return $this;
  }

  // }}}
  // {{{ isValid()

  /**
   * Valide le formulaire et retourne le resultat.
   *
   * Renvoie true si le formulaire est valide, sinon false.
   *
   * @return boolean
   */
  public function isValid()
  {
    static $error = null;

    $send = false;
    foreach( $this as $element )
      if( $element instanceof HtmlFormSubmit and ! is_null($element->value) )
        $send = true;

    if( ! $send )
      return false;

    if( is_bool($error) )
      return ! $error;
    else
      $error = false;

    foreach( $this as $element )
    {
      if( is_array($element->value) )
      {
        foreach( $element->value as $k => $v )
          $error |= $element->isValid( $v, $this );
      }
      else
        $error |= $element->isValid( (string)$element->value, $this );
    }

    return ! $error;
  }

  // }}}
  // {{{ doValid()

  /**
   * Lance la validation.
   *
   * @return HtmlForm
   */
  public function doValid()
  {
    if( $this->isValid() and $this->valid_callback )
      call_user_func( $this->valid_callback, $this );

    return $this;
  }

  // }}}
  // {{{ display()

  /**
   * @reserved
   */
  public function display()
  {
    return $this;
  }

  // }}}
  // {{{ fetch()

  /**
   * @reserved
   */
  public function fetch()
  {
    return $this;
  }

  // }}}
  // {{{ mysqlSet()

  /**
   * Retourne une portion de requ�te compatible MYSQL.
   *
   * Retourne une portion de requ�te MYSQL pr�te � �tre ajout�e dans un INSERT, un UPDATE ou un REPLACE contenant un SET.
   *
   * Utilisation avec une resource MYSQL
   * <code>
   * <?php
   *   $link = mysql_connect( 'localhost', 'root', '' );
   *   mysql_select_db( $link, 'base' );
   *   if( $set = $form->mysqlSet($link) ) // $form est une instance de HtmlForm
   *     $query = 'UPDATE table SET '.$set;
   * ?>
   * </code>
   *   
   * Utilisation avec une instance de MYSQLI
   * <code>
   * <?php
   *   $db = new mysqli( 'localhost', 'root', '', 'base' );
   *   if( $set = $form->mysqlSet($db) ) // $form est une instance de HtmlForm
   *     $query = 'UPDATE table SET '.$set;
   * ?>
   * </code>
   *
   * Utilisation avec un object contenant une m�thode escape()
   * <code>
   * <?php
   *   class db
   *   {
   *     function escape( $value )
   *     {
   *       return my_escape( $value );
   *     }
   *   }
   *   $db = new db;
   *   if( $set = $form->mysqlSet($db) ) // $form est une instance de HtmlForm
   *     $query = 'UPDATE table SET '.$set;
   * ?>
   * </code>
   *
   * @param resource|object|null Une resource ou un object.
   * @return string|false Retourne la portion de requ�te ou false en cas d'�chec.
   */
  public function mysqlSet( $link = null )
  {
    if( ! is_resource($link) and ! is_null($link) and ! is_object($link) )
      throw new InvalidArgumentException(sprintf('%s::%s() need a optional resource or object parameter.', __CLASS__, __FUNCTION__) );

    $query = '';
    foreach( $this as $e )
      if( is_string($e->map) )
      {
        if( $e instanceof HtmlFormText )
        {
          if( ! is_string($value = self::mysqlEscape( (string)$e->value, $link )) )
            return false;
          $query .= ", `{$e->map}`='{$value}'";
       }
       elseif( $e instanceof HtmlFormSelect )
       {

       }

      }

    return 'SET '.substr($query,2);
  }

  // }}}
  // {{{ mysqlValues()

  /**
   * Retourne une portions de requ�te compatible MYSQL.
   *
   * Retourne une portion de requ�te MYSQL pr�te � �tre ajout�e dans un INSERT, un UPDATE ou un REPLACE contenant un VALUES.
   *
   * Voir {@link mysqlSet()}
   *
   * @param resource|object|null Une resource ou un object.
   * @return string|false Retourne la portion de requ�te ou false en cas d'�chec.
   */
  public function mysqlValues( $link = null )
  {
    if( ! is_resource($link) and ! is_null($link) and ! is_object($link) )
      throw new InvalidArgumentException(sprintf('%s::%s() need a optional resource or object parameter.', __CLASS__, __FUNCTION__) );

    $fields = '';
    $values = '';
    foreach( $this as $e )
      if( is_string($e->map) )
      {
        if( $e instanceof HtmlFormText )
        {
          if( ! is_string($value = self::mysqlEscape( (string)$e->value, $link )) )
            return false;
          $fields .= ", `{$e->map}`";
          $values .= ", '{$value}'";
       }
      }

    return '('.substr($fields,2).') VALUES('.substr($values,2).')';
  }

  // }}}
  // {{{ mysqlDuplicateValues()

  /**
   * Retourne une portions de requ�te compatible MYSQL.
   *
   * Retourne une portion de requ�te MYSQL pr�te � �tre ajout�e dans un ON DUPLICATE KEY UPDATE.
   *
   * Voir {@link mysqlSet()}
   *
   * @return string Retourne la portion de requ�te ou false en cas d'�chec.
   */
  public function mysqlDuplicateValues()
  {
    $query = '';
    foreach( $this as $e )
      if( is_string($e->map) )
      {
        if( $e instanceof HtmlFormText )
          $query .= ", `{$e->map}`=VALUES(`{$e->map}`)";
      }

    return substr($query,2);
  }

  // }}}
  // {{{ mysqlEscape()

  /**
   * Escape une chaine pour mysql.
   *
   * @param string La cha�ne � �chapper.
   * @param resource|object|null Une resource ou un object.
   * @return string|false
   */
  static private function mysqlEscape( $value, $link = null )
  {
    if( is_object($link) and class_exists('mysqli') and $link instanceof mysqli )
      return $link->real_escape_string($value);

    elseif( is_object($link) and is_callable( array($link,'escape') ) and is_string($result = call_user_func( array($link,'escape'), $value )) )
      return $result;

    elseif( is_resource($link) and (get_resource_type($link) === 'mysql link' or get_resource_type($link) === 'mysql link persistent') )
      return mysql_real_escape_string($value, $link);

    if( function_exists('mysql_real_escape_string') and ! $result = @mysql_real_escape_string($value) )
    {
      dump( $value );
      dump( $result );
      return $result;
    }

    if( function_exists('mysql_escape_string') )
      return mysql_escape_string($value);

    return false;
  }

  // }}}
}

/**
 * Classe de champ de base
 */
class HtmlFormElement
{
  // {{{ $name

  /**
   * Le nom d'element HTML dans le formulaire
   *
   * Correspond � l'attribut name de l'element input, butto, select ou textarea.
   *
   * @var string|null
   */
  protected $name = null;

  // }}}
  // {{{ $required

  /**
   * Indique si l'element est obligatoire.
   *
   * Peut contenir un message d'erreur, si l'element est manquant.
   *
   * @var string|boolean
   */
  protected $required = false;

  // }}}
  // {{{ $check

  /**
   * Liste des v�rifications.
   *
   * Peut contenir des expressions rationnelles et des fonctions de callback
   *
   * @var array
   */
  protected $check = array();

  // }}}
  // {{{ $map

  /**
   * Le nom du champ dans la table de la base de donn�e.
   *
   * @var string
   */
  protected $map = null;

  // }}}
  // {{{ $label

  /**
   * Le label du champ.
   *
   * @var string
   */
  protected $label = null;

  // }}}
  // {{{ $alert

  /**
   * Le ou les messages d'erreur.
   *
   * @var string|array
   */
  protected $alert = null;

  // }}}
  // {{{ $id

  /**
   * Un identifiant unique permanent (ou pas)
   *
   * @var string
   */
  protected $id = null;

  // }}}
  // {{{ $error

  /**
   * L'�tat de l'erreur ou le message.
   *
   * @var string|boolean
   */
  protected $error = null;

  // }}}
  // {{{ $value

  /**
   * La valeure envoy� par le client.
   *
   * @var string
   */
  protected $value = null;

  // }}}
  // {{{ autoslashes()

  /**
   * Enl�ve les anti-slashes.
   *
   * @param string
   * @return string
   */
  static protected function autoslashes( $value )
  {
    if( get_magic_quotes_gpc() )
      return stripslashes($value);
    else
      return $value;
  }

  // }}}
  // {{{ __construct()

  /**
   * Construit un nouvel element pour le formulaire.
   *
   * @param string|null Le nom de l'element.
   */
  final public function __construct( $name = null )
  {
    if( is_null($name) )
      $this->setID( substr(md5(uniqid()),0,4) );

    if( is_string($this->name) and isset($_REQUEST[$this->name]) )
      $this->value = self::autoslashes($_REQUEST[$this->name]);

    if( is_null($name) )
    {
      $this->init();
      return;
    }

    if( ! is_string($name) ) throw new InvalidArgumentException;

    $this->setName( $name );

    $this->init();
  }

  // }}}
  // {{{ __get()

  /**
   * Surcharge les propri�t�s.
   *
   * Rend publique les propri�t�s de HtmlFormElement.
   * Retourne deux propri�t�s cach�s : class et html.
   *
   * @param string Le nom de la propri�t�.
   * @return mixed
   */
  final public function __get( $property )
  {
    if( ! is_string($property) ) throw new InvalidArgumentException;

    if( $property === 'class' )
      return get_class($this);
    elseif( $property === 'html' )
      return htmlspecialchars($this->value);

    if( ! property_exists($this,$property) ) throw new BadPropertyException( sprintf('The property "%s::%s" is undefined',get_class($this),$property) );

    return $this->$property;
  }

  // }}}
  // {{{ __set()

  /**
   * Surharge les propr�t�s.
   *
   * Permet de modifier les propri�t�s.
   *
   * @param string Le nom de la propri�t�.
   * @param mixed La nouvelle valeur.
   */
  final public function __set( $property, $value )
  {
    if( ! is_string($property) ) throw new InvalidArgumentException;

    if( ! is_callable( array($this,'set'.ucfirst($property)) ) ) throw new BadPropertyException( sprintf('The property "%s::%s" is undefined',get_class($this),$property) );

    call_user_func( array($this,'set'.ucfirst($property)), $value );
  }

  // }}}
  // {{{ isValid()

  /**
   * V�rifie si l'element est valid.
   *
   * Retourne true en cas d'erreur sinon false.
   *
   * @param string La valeur de l'element envoy� par le client.
   * @param HtmlForm Le formulaire.
   * @return boolean
   */
  final public function isValid( $value, HtmlForm $form )
  {
    if( ! is_string($value) ) throw new InvalidArgumentException;

    if( $this->required and ! @$_REQUEST[$this->name] )
      return (bool)($this->error = $this->required);

    $this->error = $error = false;

    foreach( $this->check as $check )
    {
      if( is_callable($check) )
      {
        $return = call_user_func( $check, $this, $form );
        if( ! is_string($return) and ! is_bool($return) and ! is_integer($return) )
          throw new UnexpectedValueException( 'Callback: '.print_r($check).' must return a boolean, a string or an integer.' );
        if( (is_string($return) or is_integer($return) or $return === true and is_array($this->alert)) and isset($this->alert[$return]) )
          $error |= (bool)($this->error = $this->alert[$return]);
        elseif( $return and is_string($this->alert) )
          $error |= (bool)($this->error = $this->alert);
        elseif( $return )
          $error |= (bool)($this->error = $return);
      }

      elseif( is_string($check) and ! preg_match( $check, $value ) )
      {
        if( is_string($this->alert) )
          $error |= (bool)($this->error = $this->alert);
        elseif( is_array($this->alert) and isset($this->alert[true]) )
          $error |= (bool)($this->error = $this->alert[true]);
        else
          $error |= (bool)($this->error = true);
      }

      else
        $error |= ($this->error = false);
    }

    return (bool)$error;
  }

  // }}}
  // {{{ setName()

  /**
   * Modifie le nom du champ.
   *
   * @param string
   * @return HtmlFormElement
   */
  public function setName( $name )
  {
    if( ! is_string($name) ) throw new InvalidArgumentException;
    if( substr($name,-2)=='[]' ) throw new InvalidArgumentException( sprintf('Element "%s" cannot have an array name',$name) );

    $this->name = $name;

    if( isset($_REQUEST[$this->name]) )
      $this->value = self::autoslashes($_REQUEST[$this->name]);

    return $this;
  }

  // }}}
  // {{{ setRequired()

  /**
   * Modifie le message si le champ est obligatoire.
   *
   * @param string|boolean
   * @return HtmlFormElement
   */
  public function setRequired( $required )
  {
    if( ! is_string($required) and ! is_bool($required) ) throw new InvalidArgumentException;

    $this->required = $required;
  }

  // }}}
  // {{{ setCheck()

  /**
   * Ajoute une v�rification.
   *
   * @param string Une expression rationnelle, ou une fonction de callback.
   * @return HtmlFormElement
   */
  public function setCheck( $check )
  {
    if( ! is_string($check) and ! is_array($check) ) throw new InvalidArgumentException;

    $this->check[] = $check;

    $args = func_get_args();
    if( count($args) > 1 )
    {
      array_shift($args);
      call_user_func_array( array($this,__FUNCTION__), $args );
    }

    return $this;
  }

  // }}}
  // {{{ setMap()

  /**
   * Modifie le nom du champ de la table de la base de donn�e.
   *
   * @param string
   * @return HtmlFormElement
   */
  public function setMap( $map )
  {
    if( ! is_string($map) ) throw new InvalidArgumentException;

    $this->map = $map;

    return $this;
  }

  // }}}
  // {{{ setLabel()

  /**
   * Modifie le label du champ.
   *
   * @param string
   * @return HtmlFormElement
   */
  public function setLabel( $label )
  {
    if( ! is_string($label) ) throw new InvalidArgumentException;

    $this->label = $label;

    return $this;
  }

  // }}}
  // {{{ setAlert()

  /**
   * Modifie le message ou la liste des messages d'erreur.
   *
   * @param string|array
   * @return HtmlFormElement
   */
  public function setAlert( $alert )
  {
    if( ! is_string($alert) and ! is_array($alert) ) throw new InvalidArgumentException;

    $this->alert = $alert;

    return $this;
  }

  // }}}
  // {{{ setID()

  /**
   * Modifie l'identifiant unique.
   *
   * @param string
   * @return HtmlFormElement
   */
  public function setID( $id )
  {
    if( ! is_string($id) ) throw new InvalidArgumentException;

    $this->id = $id;

    return $this;
  }

  // }}}
  // {{{ init()

  /**
   * Phase d'initialisation d'un champ.
   */
  protected function init()
  {
    if( is_null($this->map) )
      $this->setMap( $this->name );
    if( is_null($this->label) )
      $this->setLabel( ucfirst($this->name) );
    if( is_null($this->alert) )
      $this->setAlert( 'Error on field: '.$this->label );
    if( is_null($this->id) )
      $this->setID( substr(md5($this->name),0,4) );
    if( is_null($this->required) )
      $this->setRequired( 'Missing field: '.$this->name );
  }

  // }}}
}

/**
 * Classe d'un champ de type texte.
 */
class HtmlFormText extends HtmlFormElement
{
  // {{{ init()

  /**
   * Initialise un element de type text.
   *
   * V�rifie et corrige le faite que la valeur de l'element ne peut pas �tre un tableau.
   */
  protected function init()
  {
    parent::init();

    if( is_array($this->value) and $this->value )
      $this->value = array_shift($this->value);
    elseif( is_array($this->value) )
      $this->value = null;      
  }

  // }}}
}

/**
 * Classe d'un champ de type select.
 */
class HtmlFormSelect extends HtmlFormElement implements Iterator
{
  // {{{ $values

  /**
   * La listes de valeurs possibles.
   *
   * @var array
   */
  protected $values = array();

  // }}}
  // {{{ $choice

  /**
   * Le premier element de la liste.
   *
   * @var string|false
   */
  protected $choice = '-- select --';

  // }}}
  // {{{ current()

  /**
   * @ignore
   */
  public function current()
  {
    return current($this->values);
  }

  // }}}
  // {{{ next()

  /**
   * @ignore
   */
  public function next()
  {
    return next($this->values);
  }

  // }}}
  // {{{ key()

  /**
   * @ignore
   */
  public function key()
  {
    return key($this->values);
  }

  // }}}
  // {{{ rewind()

  /**
   * @ignore
   */
  public function rewind()
  {
    return reset($this->values);
  }

  // }}}
  // {{{ valid()

  /**
   * @ignore
   */
  public function valid()
  {
    return (bool)current($this->values);
  }

  // }}}
  // {{{ setChoice()

  /**
   * Modifie la premi�re valeur.
   *
   * @param string
   * @return HtmlFormSelect
   */
  public function setChoice( $choice )
  {
    if( ! is_string($choice) ) throw new InvalidArgumentException;

    $this->choice = $choice;

    return $this;
  }

  // }}}
  // {{{ init()

  /**
   * Initialise un element de type text.
   *
   * V�rifie et corrige le faite que la valeur de l'element ne peut pas �tre un tableau.
   */
  protected function init()
  {
    parent::init();

    if( is_array($this->value) and $this->value )
      $this->value = array_shift($this->value);
    elseif( is_array($this->value) )
      $this->value = null;

    array_push( $this->check, array(__CLASS__,'checkValues') );
  }

  // }}}
  // {{{ checkValues()

  /**
   * Fonction de callback.
   *
   * V�rifie si la valeur envoy� par client fait parti de la listes des valeurs possibles.
   *
   * @param HtmlFormElement
   * @param HtmlForm
   * @return boolean
   */
  static protected function checkValues( HtmlFormElement $element, HtmlForm $form )
  {
    if( ! is_array($element->values) ) throw new UnexpectedValueException(sprintf('%s::%s must be an array.',get_class($element),'$values'));

    return ! isset($element->values[$element->value]);
  }

  // }}}
}

/**
 * Classe de champ de type texte - email.
 */
class HtmlFormEmail extends HtmlFormText
{
  // {{{ $name

  protected $name = 'email';

  // }}}
  // {{{ $map

  protected $map = 'email';

  // }}}
  // {{{ $label

  protected $label = 'Email';

  // }}}
  // {{{ $check

  protected $check = array(
    '/^[a-z0-9._%-]+@[a-z0-9._%-]+\\.[a-z]{2,4}$/i'
    );

  // }}}
}

/**
 * Classe de champ de select - country.
 */
class HtmlFormCountry extends HtmlFormSelect
{
  // {{{ $name

  protected $name = 'Country';

  // }}}
  // {{{ $map

  protected $map = 'country';

  // }}}
  // {{{ $label

  protected $label = 'Country';

  // }}}
  // {{{ $values

  protected $values = array(
'AF' => 'Afghanistan',
'ZA' => 'Afrique du Sud',
'AL' => 'Albanie',
'DZ' => 'Alg&eacute;rie',
'DE' => 'Allemagne',
'AD' => 'Andorre',
'AO' => 'Angola',
'AI' => 'Anguilla',
'AQ' => 'Antarctique',
'AG' => 'Antigua-et-Barbuda',
'AN' => 'Antilles n&eacute;erlandaises',
'SA' => 'Arabie Saoudite',
'AR' => 'Argentine',
'AM' => 'Arm&eacute;nie',
'AW' => 'Aruba',
'AU' => 'Australie',
'AT' => 'Autriche',
'AZ' => 'Azerba&iuml;djan',
'BS' => 'Bahamas',
'BH' => 'Bahre&iuml;n',
'BD' => 'Bangladesh',
'BB' => 'Barbade (la)',
'BE' => 'Belgique',
'BZ' => 'Belize',
'BJ' => 'B&eacute;nin',
'BM' => 'Bermudes',
'BT' => 'Bhoutan',
'BY' => 'Bi&eacute;lorussie',
'BO' => 'Bolivie',
'BA' => 'Bosnie et Herz&eacute;govine',
'BW' => 'Botswana',
'BR' => 'Br&eacute;sil',
'BN' => 'Brunei',
'BG' => 'Bulgarie',
'BF' => 'Burkina-Faso',
'BI' => 'Burundi',
'KH' => 'Cambodge',
'CM' => 'Cameroun',
'CA' => 'Canada',
'CV' => 'Cap-Vert',
'CL' => 'Chili',
'CN' => 'Chine',
'CY' => 'Chypre',
'CO' => 'Colombie',
'KM' => 'Comores',
'CG' => 'Congo',
'CD' => 'Congo, R&eacute;publique du',
'KR' => 'Cor&eacute;e',
'KP' => 'Cor&eacute;e du Nord',
'CR' => 'Costa Rica',
'CI' => 'C&ocirc;te D\'Ivoire',
'HR' => 'Croatie',
'CU' => 'Cuba',
'DK' => 'Danemark',
'UM' => 'D&eacute;pendances am&eacute;ricaines du Pacifique',
'DJ' => 'Djibouti',
'DM' => 'Dominique (la)',
'EG' => '&Eacute;gypte',
'AE' => '&Eacute;mirats Arabes Unis',
'EC' => '&Eacute;quateur (R&eacute;publique de l\')',
'ER' => '&Eacute;rythr&eacute;e',
'ES' => 'Espagne',
'EE' => 'Estonie',
'VA' => '&Eacute;tat de la cit&eacute; du Vatican',
'US' => '&Eacute;tats-Unis',
'ET' => '&Eacute;thiopie',
'RU' => 'F&eacute;d&eacute;ration de Russie',
'FJ' => 'Fidji',
'FI' => 'Finlande',
'FR' => 'France',
'GA' => 'Gabon',
'GM' => 'Gambie',
'GE' => 'G&eacute;orgie',
'GS' => 'G&eacute;orgie du Sud et Sandwich du Sud (&Icirc;Ies)',
'GH' => 'Ghana',
'GI' => 'Gibraltar',
'GR' => 'Gr&egrave;ce',
'GD' => 'Grenade',
'GL' => 'Groenland',
'GP' => 'Guadeloupe (France DOM-TOM)',
'GU' => 'Guam',
'GT' => 'Guatemala',
'GN' => 'Guin&eacute;e',
'GQ' => 'Guin&eacute;e &Eacute;quatoriale',
'GW' => 'Guin&eacute;e-Bissau',
'GY' => 'Guyane',
'GF' => 'Guyane fran&ccedil;aise',
'HT' => 'Ha&iuml;ti',
'HN' => 'Honduras (le)',
'HK' => 'Hong Kong',
'HU' => 'Hongrie',
'CX' => '&Icirc;le Christmas',
'NF' => '&Icirc;le de Norfolk',
'MU' => '&Icirc;le Maurice',
'SJ' => '&Icirc;le Svalbard et Jan Mayen',
'BV' => '&Icirc;les Bouvet',
'KY' => '&Icirc;les Ca&iuml;mans',
'CC' => '&Icirc;les Cocos-Keeling',
'CK' => '&Icirc;les Cook',
'FO' => '&Icirc;les F&eacute;ro&eacute;',
'HM' => '&Icirc;les Heard et Mc Donald',
'FK' => '&Icirc;les Malouines',
'MH' => '&Icirc;les Marshall',
'SB' => '&Icirc;les Salomon',
'TK' => '&Icirc;les Tokelau',
'TC' => '&Icirc;les Turks et Ca&iuml;cos',
'VI' => '&Icirc;les Vierges am&eacute;ricaines',
'VG' => '&Icirc;les Vierges britanniques',
'IN' => 'Inde',
'ID' => 'Indon&eacute;sie',
'IQ' => 'Irak',
'IR' => 'Iran',
'IE' => 'Irlande',
'IS' => 'Islande',
'IL' => 'Isra&euml;l',
'IT' => 'Italie',
'LY' => 'Jamahiriya arabe libyenne (Lybie)',
'JM' => 'Jama&iuml;que',
'JP' => 'Japon',
'JO' => 'Jordanie',
'KZ' => 'Kazakhstan',
'KE' => 'Kenya',
'KG' => 'Kirghizistan',
'KI' => 'Kiribati',
'KW' => 'Kowe&iuml;t',
'LS' => 'Lesotho',
'LV' => 'Lettonie',
'LB' => 'Liban',
'LR' => 'Liberia',
'LI' => 'Liechtenstein',
'LT' => 'Lituanie',
'LU' => 'Luxembourg',
'MO' => 'Macao',
'MK' => 'Mac&eacute;doine, Ex-R&eacute;publique yougoslave de',
'MG' => 'Madagascar',
'MY' => 'Malaisie',
'MW' => 'Malawi',
'MV' => 'Maldives',
'ML' => 'Mali',
'MT' => 'Malte',
'MP' => 'Mariannes du Nord (&Icirc;les du Commonwealth)',
'MA' => 'Maroc',
'MQ' => 'Martinique (France DOM-TOM)',
'MR' => 'Mauritanie',
'YT' => 'Mayotte',
'MX' => 'Mexique',
'FM' => 'Micron&eacute;sie',
'MD' => 'Moldavie',
'MC' => 'Monaco',
'MN' => 'Mongolie',
'MS' => 'Montserrat',
'MZ' => 'Mozambique',
'MM' => 'Myanmar (Union de)',
'NA' => 'Namibie',
'NR' => 'Nauru (R&eacute;publique de)',
'NP' => 'N&eacute;pal',
'NI' => 'Nicaragua',
'NE' => 'Niger',
'NG' => 'Nig&eacute;ria',
'NU' => 'Niue',
'NO' => 'Norv&egrave;ge',
'NC' => 'Nouvelle Cal&eacute;donie',
'NZ' => 'Nouvelle Z&eacute;lande',
'OM' => 'Oman',
'UG' => 'Ouganda',
'UZ' => 'Ouzb&eacute;kist&auml;n',
'PK' => 'Pakistan',
'PW' => 'Palau',
'PA' => 'Panama',
'PG' => 'Papouasie Nouvelle-Guin&eacute;e',
'PY' => 'Paraguay',
'NL' => 'Pays-Bas',
'PE' => 'P&eacute;rou',
'PH' => 'Philippines',
'PN' => 'Pitcairn (&Icirc;les)',
'PL' => 'Pologne',
'PF' => 'Polyn&eacute;sie fran&ccedil;aise (DOM-TOM)',
'PR' => 'Porto Rico',
'PT' => 'Portugal',
'QA' => 'Qatar',
'SY' => 'R&eacute;publique arabe syrienne',
'CF' => 'R&eacute;publique Centrafricaine',
'LA' => 'R&eacute;publique d&eacute;mocratique populaire du Laos',
'DO' => 'R&eacute;publique Dominicaine',
'CZ' => 'R&eacute;publique tch&egrave;que',
'RE' => 'R&eacute;union (&Icirc;le de la)',
'RO' => 'Roumanie',
'UK' => 'Royaume-Uni',
'RW' => 'Rwanda',
'SH' => 'Sainte H&eacute;l&egrave;ne',
'LC' => 'Saint-Lucie',
'SM' => 'Saint-Marin',
'PM' => 'Saint-Pierre-et-Miquelon (France DOM-TOM)',
'VC' => 'Saint-Vincent et les Grenadines',
'SV' => 'Salvador',
'WS' => 'Samoa',
'AS' => 'Samoa am&eacute;ricaines',
'ST' => 'S&acirc;o Tom&eacute; et Prince',
'SN' => 'S&eacute;n&eacute;gal',
'SC' => 'Seychelles',
'SL' => 'Sierra Leone',
'SG' => 'Singapour',
'SK' => 'Slovaquie',
'SI' => 'Slov&eacute;nie',
'SO' => 'Somalie',
'SD' => 'Soudan',
'LK' => 'Sri Lanka',
'KN' => 'St Christopher et Nevis (&Icirc;les)',
'SE' => 'Su&egrave;de',
'CH' => 'Suisse',
'SR' => 'Suriname',
'SZ' => 'Swaziland',
'TW' => 'Taiwan',
'TJ' => 'Tajikistan',
'TZ' => 'Tanzanie',
'TD' => 'Tchad',
'TF' => 'Terres Australes fran&ccedil;aises (DOM-TOM)',
'IO' => 'Territoires Britanniques de l\'oc&eacute;an Indien',
'TH' => 'Tha&iuml;lande',
'TP' => 'Timor oriental (partie orientale)',
'TG' => 'Togo',
'TO' => 'Tonga',
'TT' => 'Trinit&eacute;-et-Tobago',
'TN' => 'Tunisie',
'TM' => 'Turkm&eacute;nistan',
'TR' => 'Turquie',
'TV' => 'Tuvalu (&Icirc;les)',
'UA' => 'Ukraine',
'UY' => 'Uruguay',
'VU' => 'Vanuatu (R&eacute;publique de)',
'VE' => 'Venezuela',
'VN' => 'Vietnam',
'WF' => 'Wallis et Futuna',
'YE' => 'Y&eacute;men',
'YU' => 'Yougoslavie',
'ZM' => 'Zambie',
'ZW' => 'Zimbabwe',
'--' => 'Autre' );

  // }}}
  // {{{ $check

  protected $check = array(
    '/(?:[A-Z]{2}|--)$/' );

  // }}}
  // {{{ init()

  protected function init()
  {
    parent::init();

    $this->setChoice( '-- select a country --' );
  }

  // }}}
}

class HtmlFormButton extends HtmlFormElement
{
}

class HtmlFormSubmit extends HtmlFormButton
{
  // {{{ $name

  protected $name = 'submit';

  // }}}
  // {{{ $map

  protected $map = null;

  // }}}
  // {{{ $label

  protected $label = 'Submit';

  // }}}
  // {{{ $required

  protected $required = 'Form must be submited';

  // }}}
}

/**
 * @ignore
 */
if( ! class_exists('BadPropertyException') )
{
  class BadPropertyException extends LogicException
  {
  }
}

interface HtmlOutInterface
{
  // {{{ display()

  static public function display( HtmlForm $form );

  // }}}
  // {{{ fetch()

  static public function fetch( HtmlForm $form );

  // }}}
}

final class HtmlOut implements HtmlOutInterface
{
  // {{{ display()

  static public function display( HtmlForm $form )
  {
    echo self::fetch( $form );
  }

  // }}}
  // {{{ fetch()

  static public function fetch( HtmlForm $form )
  {
    $form->doValid();

    $buffer = <<<HTML
<form name="{$form->name}" method="{$form->method}">

HTML;

    foreach( $form as $element )
    {
      $result = '';
      switch( true )
      {
      case $element instanceof HtmlFormText :
        $result = self::text( $element );
        break;
      case $element instanceof HtmlFormSelect :
        $result = self::select( $element );
        break;
      case $element instanceof HtmlFormButton :
        $result = self::button( $element );
        break;
      }
      if( ! is_string($result) )
        throw new UnexpectedValueException( sprintf('The methode "%s::%s" need return a string.',__CLASS__,$method_name) );
      $buffer .= $result;
    }

    $buffer .= <<<HTML
</form>

HTML;

    return $buffer;
  }

  // }}}
  // {{{ prepare_fetch()

  static private function prepare_fetch( HtmlFormElement $element, &$value, &$alert, &$error )
  {
    $value = htmlspecialchars($element->value);

    if( is_string($element->error) )
      $alert = <<<HTML
    <div class="alert">
      {$element->error}
    </div>

HTML;
    else
      $alert = '';

    if( $element->error )
      $error = ' error';
    else
      $error = '';
  }

  // }}}
  // {{{ text()

  static protected function text( HtmlFormText $e )
  {
    self::prepare_fetch( $e, $v, $alert, $error );

    return <<<HTML
  <div class="{$e->name}{$error}">
    <div class="label"><label for="{$e->id}">{$e->label}</label></div>
    <div class="field"><input id="{$e->id}" type="text" name="{$e->name}" value="{$v}" /></div>
{$alert}
  </div>

HTML;
  }

  // }}}
  // {{{ select()

  static protected function select( HtmlFormSelect $e )
  {
    self::prepare_fetch( $e, $v, $alert, $error );

    if( is_string($e->choice) )
      $options = <<<HTML
    <option value="">{$e->choice}</option>

HTML;
    else
      $options = '';

    foreach( $e as $key => $value )
    {
      if( is_array($v) )
        $selected = isset($v[$key]);
      elseif( is_string($v) )
        $selected = ($v===$key);
      else
        $selected = false;
      if( $selected )
        $selected = ' selected="selected"';
      $options .= <<<HTML
      <option value="{$key}"{$selected}>{$value}</option>

HTML;
    }
    return <<<HTML
  <div class="{$e->name}{$error}">
    <div class="label"><label>{$e->label}</label></div>
    <div class="field"><select name="{$e->name}">
{$options}
    </select></div>
{$alert}
  </div>

HTML;
  }

  // }}}
  // {{{ button()

  static protected function button( HtmlFormButton $e )
  {
    self::prepare_fetch( $e, $v, $alert, $error );

    if( $e instanceof HtmlFormSubmit )
      $type = 'submit';
    else
      $type = 'button';
    return <<<HTML
  <div class="{$e->name}{$error}">
    <div class="field"><input type="{$type}" name="{$e->name}" value="{$e->label}" /></div>
{$alert}
  </div>

HTML;
  }

  // }}}
} 

?>
