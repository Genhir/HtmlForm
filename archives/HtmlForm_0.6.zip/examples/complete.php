<h1>A complete example with french translation</h1>
<hr/>
<?php

require_once( '../HtmlForm.php' );

// extend the base country class
class HtmlFormPays extends HtmlFormCountry
{
  // use french translation
  protected $choice = '-- Choisissez un pays --';
  protected $name = 'pays';
  protected $label = 'Pays';

  protected function init()
  {
    parent::init();

    // use the french class translation : HtmlFormCountryFrenchI18n
    $this->i18n = new HtmlFormCountryFrenchI18n( $this );
  }
}

// executed when the form being validate
function valid( HtmlForm $form )
{
  echo <<<HTML
<h1>Valid!</h1>
<pre>INSERT users {$form->mysqlSet()} ON DUPLICATE KEY UPDATE {$form->mysqlDuplicateValues()}</pre>

HTML;
  exit;
}

// a callback function to check the value of the country field 
function verif_pays( HtmlFormElement $element, HtmlForm $form )
{
  if( $element->value == 'FR' )
    return 'noFR';
  else
    return false;
}

// create a new form ...
$form = HtmlForm::hie('inscription')

  // ... and add some field
  ->text('nom')->required('Vous devez saisir votre nom')->check('/^\w{4,16}$/')->alert('Vous devez saisir entre 3 et 16 lettres et chiffres uniquement.')
  ->email()->label('Adresse m�l')
  ->pays()->required('Indiquer votre pays')->check('verif_pays')->alert(array(
    true=>'Utilisez la liste d�roulante svp !',
    'noFR'=>'Vous ne pouvez pas habiter en france'))
  ->submit()->label('Envoyer')

  ->onValid('valid');

// display the form
HtmlOut::display( $form );

?>
<style>
.error { background: #f99; }
</style>
