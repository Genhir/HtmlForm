<h1>HtmlForm Examples</h1>
<hr/>
<h2><a href="simple.php">A simple example</a></h2>
<h2><a href="complete.php">A complete example</a></h2>
<h2><a href="multiple_pages.php">A multiple pages exemple</a></h2>
<hr>
<h3>By fields</h3>
<ul>
  <li><a href="day.php">Day typed field</a></li>
  <li><a href="email.php">Email typed field</a></li>
  <li><a href="month.php">Month dropdown field</a></li>
  <li><a href="text.php">Text typed field</a></li>
  <li><a href="year.php">Year typed field</a></li>
  <li><a href="yeardown.php">Year dropdown field</a></li>
</ul>
