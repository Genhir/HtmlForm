<?php

/**
 * Operations pour formulaire.
 *
 * Fourni une impl�mentation g�n�rique des diverses op�rations effectu� autour des formulaire HTML.
 * Prend en charge l'affichage des champs, le controle des donn�es et la construction de la requ�te SQL.
 *
 * @author martin mauchauff�e Htmlform@moechofe.com
 * @version 0.8
 */

/**
 * Classe de formulaire.
 */
class HtmlForm implements ArrayAccess, Iterator
{
  // {{{ $name

  /**
   * Le nom de formulaire.
   *
   * Correspond a l'attribut name de la balise form.
   *
   * @var string|null
   */
  private $name = null;

  // }}}
  // {{{ $names

  /**
   * La liste de tous les noms des formulaire d�j� instancier
   *
   * @var array
   */
  static private $names = array();

  // }}}
  // {{{ $elements

  /**
   * Liste des elements du formulaire.
   *
   * Contient un tableau dont les clefs sont les noms de balises et les valeurs sont des instances de HtmlFormElement
   *
   * @var array
   */
  private $elements = array();

  // }}}
  // {{{ $current

  /**
   * Un pointeur sur le dernier element ajout� dans le formulaire.
   *
   * @var HtmlFormElement
   */
  private $current = null;

  // }}}
  // {{{ $method

  /**
   * La m�thode d'envoie du formulaire.
   *
   * Correpond � l'attribut method de la balise form.
   *
   * @var string
   */
  private $method = 'post';

  // }}}
  // {{{ $valid_callback

  /**
   * Fonction de callback.
   *
   * Le nom d'une fonction de callback � appeler si le formulaire est valide.
   *
   * @var string
   */
  private $valid_callback = false;

  // }}}
  // {{{ $send

  /**
   * Indique si le formulaire � �t� envoy�.
   *
   * @var bool
   */
  private $send = false;

  // }}}
  // {{{ __construct()

  /**
   * Contruit un nouveau formulaire.
   *
   * @param string Le nom du formulaire correspond � l'attribut name de la balise form.
   */
  protected function __construct( $name )
  {
    if( ! is_string($name) ) throw new InvalidArgumentException;
    if( ! preg_match('/^[_\w-]+$/', $name ) ) throw new InvalidArgumentException;

    $this->name = $name;
  }

  // }}}
  // {{{ __call()

  /**
   * Surcharge des m�thodes.
   *
   * Appel une m�thode setxxxx de l'el�ment pr�cedement ajout�, ou
   * contruit un nouvel object d'un classe HtmlFormxxxxx,
   * o� xxxx est le nom de la m�thode surcharg�.
   *
   * @param string Le nom de la m�thode surcharg�e.
   * @param array Les param�tres pass� � la m�thode.
   * @return HtmlForm
   */
  public function __call( $method, $arguments )
  {
    if( ! is_string($method) ) throw new InvalidArgumentException;
    if( ! is_array($arguments) ) throw new InvalidArgumentException;

    if( $method == 'i18n' and $this->current instanceof HtmlFormElement and is_callable( $callback = array($this->current,'setI18n') ) )
    {
      call_user_func_array( $callback, array_merge( array($this->current), $arguments ) );
      return $this;
    }

    if( $this->current instanceof HtmlFormElement and is_callable( $callback = array($this->current,'set'.ucfirst($method)) ) )
    {
      call_user_func_array( $callback, $arguments );
      return $this;
    }

    if( ! class_exists($class_name = 'HtmlForm'.ucfirst($method)) )
      throw new BadMethodCallException(sprintf('Try to append an unexists element class: %s', $class_name));

    if( ! is_subclass_of($class_name,'HtmlFormElement') )
      throw new BadMethodCallException(sprintf('The element class: %s isn\'t an child of the class: HtmlFormElement', $class_name));

    return $this->appendElement( call_user_func_array( array($class_name,'hie'), array_merge(array($this,$class_name),$arguments) ) );
  }

  // }}}
  // {{{ __get()

  /**
   * Surcharge des propri�t�s.
   *
   * Rend publique les propri�t�s de la class HtmlForm.
   * Renvoie en plus une propri�t� cach� : error
   *
   * @param Le nom de la propri�t�.
   * @return mixed
   */
  public function __get( $property )
  {
    if( ! is_string($property) ) throw new InvalidArgumentException;

    if( $property === 'error' )
    {
      foreach( $this->elements as $element )
        if( $element->error )
          return true;
      return false;
    }

    if( ! isset($this->$property) ) throw new BadPropertyException( sprintf('The property "%s::%s" is undefined',get_class($this),$property) );

    return $this->$property;
  }

  // }}}
  // {{{ hie()

  /**
   * Instancie un nouveau formulaire.
   *
   * @param string Le nom du formulaire correspond � l'attribut name de la balise form.
   * @return HtmlForm
   */
  static public function hie( $name )
  {
    if( ! is_string($name) ) throw new InvalidArgumentException;
    if( ! preg_match('/^[_\w-]+$/', $name ) ) throw new InvalidArgumentException;
    if( isset(self::$names[$name]) ) throw new InvalidArgumentException(sprintf('%s::%s() need a unique name to define the form',__CLASS__,__FUNCTION__));

    $form = new self( $name );
    self::$names[$name] = $form;
    return $form;
  }

  // }}}
  // {{{ appendElement()

  /**
   * Ajout une �l�ment dans le formulaire
   *
   * @param HtmlFormElement
   * @return HtmlForm
   */
  public function appendElement( HtmlFormElement $element )
  {
    $this->current = $element;
    $this->elements[ $element->name ] = $element;
    return $this;
  }

  // }}}
  // {{{ selectElement()

  /***
   * Selectionne un �l�ment
   *
   * @param string Le nom de l'instance de l'�l�ment.
   * @return HtmlForm
   */
  public function selectElement( $name )
  {
    if( ! is_string($name) ) throw new InvalidArgumentException;

    if( ! isset($this->elements[ $name ]) ) throw new OutOfBoundsException;

    $this->current = $this->elements[ $name ];

    return $this;
  }

  // }}}
  // {{{ setPost()

  /**
   * Indique d'envoyer le formulaire en POST
   *
   * @return HtmlForm
   */
  public function setPost()
  {
    $this->method = 'post';
    return $this;
  }

  // }}}
  // {{{ setGet()

  /**
   * Indique d'envoyer le formulaire en GET
   *
   * @return HtmlForm
   */
  public function setGet()
  {
    $this->method = 'get';
    return $this;
  }

  // }}}
  // {{{ current()

  /**
   * @ignore
   */
  public function current()
  {
    return current($this->elements);
  }

  // }}}
  // {{{ next()

  /**
   * @ignore
   */
  public function next()
  {
    return next($this->elements);
  }

  // }}}
  // {{{ key()

  /**
   * @ignore
   */
  public function key()
  {
    return key($this->elements);
  }

  // }}}
  // {{{ rewind()

  /**
   * @ignore
   */
  public function rewind()
  {
    return reset($this->elements);
  }

  // }}}
  // {{{ valid()

  /**
   * @ignore
   */
  public function valid()
  {
    return (bool)current($this->elements);
  }

  // }}}
  // {{{ offsetExists()

  /**
   * @ignore
   */
  public function offsetExists( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    return isset($this->elements[$offset]);
  }

  // }}}
  // {{{ offsetGet()

  /**
   * @ignore
   */
  public function offsetGet( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    if( ! isset($this->elements[$offset]) ) throw new OutOfBoundsException(sprintf('Try to acces to an undefined index: %.',$offset));

    return $this->elements[$offset];
  }

  // }}}
  // {{{ offsetSet()

  /**
   * @ignore
   */
  public function offsetSet( $offset, $value )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;
    if( ! $value instanceof HtmlFormElement ) throw new InvalidArgumentException;

    $this->elements[$offset] = $value;
  }

  // }}}
  // {{{ offsetUnset()

  /**
   * @ignore
   */
  public function offsetUnset( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    if( ! isset($this->elements[$offset]) ) throw new OutOfBoundsException(sprintf('Try to acces to an undefined index: %.',$offset));

    unset( $this->elements[$offset] );
  }

  // }}}
  // {{{ onValid()

  /**
   * Sp�cifie une fonction de callback.
   *
   * Cette fonction sera appel� si le formulaire est valid�.
   *
   * @param string Une fonction de callback valide.
   * @return HtmlForm
   */
  public function onValid( $function )
  {
    if( ! is_callable($function) ) throw new InvalidArgumentException( sprintf('The function "%s" isn\'t callable.',print_r($function,true)) );

    $this->valid_callback = $function;

    return $this;
  }

  // }}}
  // {{{ isSent()

  public function isSent()
  {
    foreach( $this as $element )
      if( $element instanceof HtmlFormSubmit and ! is_null($element->value) )
        $this->send = true;
  }

  // }}}
  // {{{ isValid()

  /**
   * Valide le formulaire et retourne le resultat.
   *
   * Renvoie true si le formulaire est valide, sinon false.
   *
   * @return boolean
   */
  public function isValid()
  {
    static $error = null;

    $this->isSent();

    if( ! $this->send )
      return false;

    if( is_bool($error) )
      return ! $error;
    else
      $error = false;

    foreach( $this as $element )
    {
      if( ! $element->required )
      {
        if( is_array($element->value) and $element->value )
          continue;
        elseif( (string)$element->value === '' )
          continue;
      }
      if( is_array($element->value) )
      {
        foreach( $element->value as $k => $v )
          $error |= $element->ifError( $v, $this );
      }
      else
        $error |= $element->ifError( (string)$element->value, $this );
    }

    return ! $error;
  }

  // }}}
  // {{{ doValid()

  /**
   * Lance la validation.
   *
   * @return HtmlForm
   */
  public function doValid()
  {
    if( $this->isValid() and $this->valid_callback )
      call_user_func( $this->valid_callback, $this );

    return $this;
  }

  // }}}
  // {{{ display()

  /**
   * @reserved
   */
  public function display()
  {
    return $this;
  }

  // }}}
  // {{{ fetch()

  /**
   * @reserved
   */
  public function fetch()
  {
    return $this;
  }

  // }}}
  // {{{ mysqlSet()

  /**
   * Retourne une portion de requ�te compatible MYSQL.
   *
   * Retourne une portion de requ�te MYSQL pr�te � �tre ajout�e dans un INSERT, un UPDATE ou un REPLACE contenant un SET.
   *
   * Utilisation avec une resource MYSQL
   * <code>
   * <?php
   *   $link = mysql_connect( 'localhost', 'root', '' );
   *   mysql_select_db( $link, 'base' );
   *   if( $set = $form->mysqlSet($link) ) // $form est une instance de HtmlForm
   *     $query = 'UPDATE table SET '.$set;
   * ?>
   * </code>
   *   
   * Utilisation avec une instance de MYSQLI
   * <code>
   * <?php
   *   $db = new mysqli( 'localhost', 'root', '', 'base' );
   *   if( $set = $form->mysqlSet($db) ) // $form est une instance de HtmlForm
   *     $query = 'UPDATE table SET '.$set;
   * ?>
   * </code>
   *
   * Utilisation avec un object contenant une m�thode escape()
   * <code>
   * <?php
   *   class db
   *   {
   *     function escape( $value )
   *     {
   *       return my_escape( $value );
   *     }
   *   }
   *   $db = new db;
   *   if( $set = $form->mysqlSet($db) ) // $form est une instance de HtmlForm
   *     $query = 'UPDATE table SET '.$set;
   * ?>
   * </code>
   *
   * @param resource|object|null Une resource ou un object.
   * @return string|false Retourne la portion de requ�te ou false en cas d'�chec.
   */
  public function mysqlSet( $link = null )
  {
    if( ! is_resource($link) and ! is_null($link) and ! is_object($link) )
      throw new InvalidArgumentException(sprintf('%s::%s() need a optional resource or object parameter.', __CLASS__, __FUNCTION__) );

    $query = '';
    foreach( $this as $e )
      if( is_string($e->map) )
      {
        if( ! is_string($value = self::mysqlEscape( (string)$e->value, $link )) )
          return false;
        $query .= ", `{$e->map}`='{$value}'";
      }

    return 'SET '.substr($query,2);
  }

  // }}}
  // {{{ mysqlValues()

  /**
   * Retourne une portions de requ�te compatible MYSQL.
   *
   * Retourne une portion de requ�te MYSQL pr�te � �tre ajout�e dans un INSERT, un UPDATE ou un REPLACE contenant un VALUES.
   *
   * Voir {@link mysqlSet()}
   *
   * @param resource|object|null Une resource ou un object.
   * @return string|false Retourne la portion de requ�te ou false en cas d'�chec.
   */
  public function mysqlValues( $link = null )
  {
    if( ! is_resource($link) and ! is_null($link) and ! is_object($link) )
      throw new InvalidArgumentException(sprintf('%s::%s() need a optional resource or object parameter.', __CLASS__, __FUNCTION__) );

    $fields = '';
    $values = '';
    foreach( $this as $e )
      if( is_string($e->map) )
      {
        if( ! is_string($value = self::mysqlEscape( (string)$e->value, $link )) )
          return false;
        $fields .= ", `{$e->map}`";
        $values .= ", '{$value}'";
      }

    return '('.substr($fields,2).') VALUES('.substr($values,2).')';
  }

  // }}}
  // {{{ mysqlDuplicateValues()

  /**
   * Retourne une portions de requ�te compatible MYSQL.
   *
   * Retourne une portion de requ�te MYSQL pr�te � �tre ajout�e dans un ON DUPLICATE KEY UPDATE.
   *
   * Voir {@link mysqlSet()}
   *
   * @return string Retourne la portion de requ�te ou false en cas d'�chec.
   */
  public function mysqlDuplicateValues()
  {
    $query = '';
    foreach( $this as $e )
      if( is_string($e->map) )
      {
        $query .= ", `{$e->map}`=VALUES(`{$e->map}`)";
      }

    return substr($query,2);
  }

  // }}}
  // {{{ mysqlEscape()

  /**
   * Escape une chaine pour mysql.
   *
   * @param string La cha�ne � �chapper.
   * @param resource|object|null Une resource ou un object.
   * @return string|false
   */
  static private function mysqlEscape( $value, $link = null )
  {
    if( is_object($link) and class_exists('mysqli') and $link instanceof mysqli )
      return $link->real_escape_string($value);

    elseif( is_object($link) and is_callable( array($link,'escape') ) and is_string($result = call_user_func( array($link,'escape'), $value )) )
      return $result;

    elseif( is_resource($link) and (get_resource_type($link) === 'mysql link' or get_resource_type($link) === 'mysql link persistent') )
      return mysql_real_escape_string($value, $link);

    if( function_exists('mysql_real_escape_string') and ! $result = @mysql_real_escape_string($value) )
    {
      return $result;
    }

    if( function_exists('mysql_escape_string') )
      return mysql_escape_string($value);

    return false;
  }

  // }}}
}

/**
 * Classe pour l'internationalisation des �l�ments.
 */
abstract class HtmlFormI18n implements ArrayAccess, Iterator
{
  // {{{ $strings

  /**
   * Un tableau des cha�nes traduite
   */
  protected $strings = array();

  // }}}
  // {{{ $element

  /**
   * Une r�f�rence vers l'�l�ment traduit.
   */
  protected $element = null;

  // }}}
  // {{{ __construct()

  final public function __construct( HtmlFormElement $element )
  {
    $this->element = $element;
  }

  // }}}
  // {{{ current()

  /**
   * @ignore
   */
  public function current()
  {
    return current($this->strings);
  }

  // }}}
  // {{{ next()

  /**
   * @ignore
   */
  public function next()
  {
    return next($this->strings);
  }

  // }}}
  // {{{ key()

  /**
   * @ignore
   */
  public function key()
  {
    return key($this->strings);
  }

  // }}}
  // {{{ rewind()

  /**
   * @ignore
   */
  public function rewind()
  {
    return reset($this->strings);
  }

  // }}}
  // {{{ valid()

  /**
   * @ignore
   */
  public function valid()
  {
    return (bool)current($this->strings);
  }

  // }}}
  // {{{ offsetExists()

  /**
   * @ignore
   */
  public function offsetExists( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    return isset($this->strings[$offset]);
  }

  // }}}
  // {{{ offsetGet()

  /**
   * @ignore
   */
  public function offsetGet( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    if( ! isset($this->strings[$offset]) ) throw new OutOfBoundsException(sprintf('Try to acces to an undefined index: %.',$offset));

    return $this->strings[$offset];
  }

  // }}}
  // {{{ offsetSet()

  /**
   * @ignore
   */
  public function offsetSet( $offset, $value )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;
    if( ! $value instanceof HtmlFormElement ) throw new InvalidArgumentException;

    $this->strings[$offset] = $value;
  }

  // }}}
  // {{{ offsetUnset()

  /**
   * @ignore
   */
  public function offsetUnset( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    if( ! isset($this->strings[$offset]) ) throw new OutOfBoundsException(sprintf('Try to acces to an undefined index: %.',$offset));

    unset( $this->strings[$offset] );
  }

  // }}}
}

/**
 * Classe de champ de base.
 */
class HtmlFormElement
{
  // {{{ $form

  /**
   * L'instance du forumlaire
   * 
   * @var HtmlForm
   */
  private $form = null;

  // }}}
  // {{{ $name

  /**
   * Le nom d'element HTML dans le formulaire
   *
   * Correspond � l'attribut name de l'element input, butto, select ou textarea.
   *
   * @var string|null
   */
  protected $name = null;

  // }}}
  // {{{ $required

  /**
   * Indique si l'element est obligatoire.
   *
   * Peut contenir un message d'erreur, si l'element est manquant.
   *
   * @var string|boolean
   */
  protected $required = false;

  // }}}
  // {{{ $check

  /**
   * Liste des v�rifications.
   *
   * Peut contenir des expressions rationnelles et des fonctions de callback
   *
   * @var array
   */
  protected $check = array();

  // }}}
  // {{{ $map

  /**
   * Le nom du champ dans la table de la base de donn�e.
   *
   * @var string
   */
  protected $map = null;

  // }}}
  // {{{ $label

  /**
   * Le label du champ.
   *
   * @var string
   */
  protected $label = null;

  // }}}
  // {{{ $alert

  /**
   * Le ou les messages d'erreur.
   *
   * @var string|array
   */
  protected $alert = null;

  // }}}
  // {{{ $id

  /**
   * Un identifiant unique permanent (ou pas)
   *
   * @var string
   */
  protected $id = null;

  // }}}
  // {{{ $error

  /**
   * L'�tat de l'erreur ou le message.
   *
   * @var string|boolean
   */
  protected $error = null;

  // }}}
  // {{{ $i18n

  /**
   * L'object pour l'internationalisation;
   *
   * @var HtmlFormI18n
   */
  protected $i18n = null;

  // }}}
  // {{{ $default

  /**
   * Une valeur par d�faut.
   *
   * @var string|array|boolean
   */
  protected $default = null;

  // }}}
  // {{{ autoslashes()

  /**
   * Enl�ve les anti-slashes.
   *
   * @param string
   * @return string
   */
  static protected function autoslashes( $value )
  {
    if( get_magic_quotes_gpc() )
      return stripslashes($value);
    else
      return $value;
  }

  // }}}
  // {{{ hie()

  /**
   * Instancie un �l�ment
   *
   * @param HtmlForm
   * @param string Le nom de la classe � instancier
   * @param string Le nom de l'�l�ment
   * @return HtmlFormElement
   */
  static public function hie( HtmlForm $form, $class_name )
  {
    if( ! is_string($class_name) ) throw new InvalidArgumentException(sprintf('%s::%s need a string for his 2nd parametre.',__CLASS__,__FUNCTION__));

    if( func_num_args() > 2 ) $name = func_get_arg(2); else $name = null;

    if( ! is_string($name) and ! is_null($name) ) throw new InvalidArgumentException(sprintf('%::%s need a string for his 3rd parameter.',__CLASS__,__FUNCTION__));

    return new $class_name( $form, $name );
  }

  // }}}
  // {{{ __construct()

  /**
   * Construit un nouvel element pour le formulaire.
   *
   * @param HtmlForm
   * @param string|null Le nom de l'element.
   */
  protected function __construct( HtmlForm $form, $name = null )
  {
    $this->form = $form;

    if( is_null($name) )
      $this->setID( substr(md5(uniqid()),0,4) );

    if( is_null($name) )
    {
      $this->init( $form );
      return;
    }

    if( ! is_string($name) ) throw new InvalidArgumentException;

    $this->setName( $name );

    $this->init( $form );
  }

  // }}}
  // {{{ __get()

  /**
   * Surcharge les propri�t�s.
   *
   * Rend publique les propri�t�s de HtmlFormElement.
   * Retourne deux propri�t�s cach�s : class et html.
   *
   * @param string Le nom de la propri�t�.
   * @return mixed
   */
  public function __get( $property )
  {
    if( ! is_string($property) ) throw new InvalidArgumentException;

    if( $property === 'class' )
      return get_class($this);
    elseif( $property === 'value' and $this->form->send )
      return self::autoslashes($this->getValue());
    elseif( $property === 'value' and $this->default )
      return $this->default;
    elseif( $property === 'value' )
      return null;
    elseif( $property === 'html' and $this->form->send )
      return htmlspecialchars(self::autoslashes($this->getValue()));
    elseif( $property === 'html' and $this->default )
      return htmlspecialchars($this->default);
    elseif( $property === 'html' )
      return null;

    if( ! property_exists($this,$property) ) throw new BadPropertyException( sprintf('The property "%s::%s" is undefined',get_class($this),$property) );

    return $this->$property;
  }

  // }}}
  // {{{ __set()

  /**
   * Surharge les propr�t�s.
   *
   * Permet de modifier les propri�t�s.
   *
   * @param string Le nom de la propri�t�.
   * @param mixed La nouvelle valeur.
   */
  public function __set( $property, $value )
  {
    if( ! is_string($property) ) throw new InvalidArgumentException;

    if( ! is_callable( array($this,'set'.ucfirst($property)) ) ) throw new BadPropertyException( sprintf('The property "%s::%s" is undefined',get_class($this),$property) );

    call_user_func( array($this,'set'.ucfirst($property)), $value );
  }

  // }}}
  // {{{ ifError()

  /**
   * V�rifie si l'element est valid.
   *
   * Retourne true en cas d'erreur sinon false.
   *
   * @param string La valeur de l'element envoy� par le client.
   * @param HtmlForm Le formulaire.
   * @return boolean
   */
  public function ifError( $value, HtmlForm $form )
  {
    if( ! is_string($value) ) throw new InvalidArgumentException;

    if( $this->required and $this->value==='' )
      return (bool)($this->error = $this->required);

    $this->error = $error = false;

    foreach( $this->check as $check )
    {
      if( is_callable($check) )
      {
        $return = call_user_func( $check, $this, $form );
        if( ! is_string($return) and ! is_bool($return) and ! is_integer($return) )
          throw new UnexpectedValueException( 'Callback: '.print_r($check).' must return a boolean, a string or an integer.' );
        if( (is_string($return) or is_integer($return) or $return === true and is_array($this->alert)) and isset($this->alert[$return]) )
          $error |= (bool)($this->error = $this->alert[$return]);
        elseif( $return and is_string($this->alert) )
          $error |= (bool)($this->error = $this->alert);
        elseif( $return )
          $error |= (bool)($this->error = $return);
      }

      elseif( is_string($check) and ! preg_match( $check, $value ) )
      {
        if( is_string($this->alert) )
          $error |= (bool)($this->error = $this->alert);
        elseif( is_array($this->alert) and isset($this->alert[true]) )
          $error |= (bool)($this->error = $this->alert[true]);
        else
          $error |= (bool)($this->error = true);
      }

      else
        $error |= ($this->error = false);
    }

    return (bool)$error;
  }

  // }}}
  // {{{ setName()

  /**
   * Modifie le nom du champ.
   *
   * @param string
   * @return HtmlFormElement
   */
  public function setName( $name )
  {
    if( ! is_string($name) ) throw new InvalidArgumentException;
    if( substr($name,-2)=='[]' ) throw new InvalidArgumentException( sprintf('Element "%s" cannot have an array name',$name) );

    $this->name = $name;

    return $this;
  }

  // }}}
  // {{{ setRequired()

  /**
   * Modifie le message si le champ est obligatoire.
   *
   * @param string|boolean
   * @return HtmlFormElement
   */
  public function setRequired( $required )
  {
    if( ! is_string($required) and ! is_bool($required) ) throw new InvalidArgumentException;

    if( $required === true )
      $this->required = 'Missing field: '.$this->name;
    else
    $this->required = $required;
  }

  // }}}
  // {{{ setCheck()

  /**
   * Ajoute une v�rification.
   *
   * @param string Une expression rationnelle, ou une fonction de callback.
   * @return HtmlFormElement
   */
  public function setCheck( $check )
  {
    if( ! is_string($check) and ! is_array($check) ) throw new InvalidArgumentException;

    $this->check[] = $check;

    $args = func_get_args();
    if( count($args) > 1 )
    {
      array_shift($args);
      call_user_func_array( array($this,__FUNCTION__), $args );
    }

    return $this;
  }

  // }}}
  // {{{ setMap()

  /**
   * Modifie le nom du champ de la table de la base de donn�e.
   *
   * @param string|null
   * @return HtmlFormElement
   */
  public function setMap( $map )
  {
    if( ! is_string($map) and ! is_null($map) ) throw new InvalidArgumentException(sprintf('%s::%s() need a string for his 1st parameter',__CLASS__,__FUNCTION__));

    $this->map = $map;

    return $this;
  }

  // }}}
  // {{{ setLabel()

  /**
   * Modifie le label du champ.
   *
   * @param string|false
   * @return HtmlFormElement
   */
  public function setLabel( $label )
  {
    if( ! is_string($label) and ! $label === false ) throw new InvalidArgumentException(sprintf('%s::%s() need a string or a false value for his 1st parameter',__CLASS__,__FUNCTION__));

    $this->label = $label;

    return $this;
  }

  // }}}
  // {{{ setAlert()

  /**
   * Modifie le message ou la liste des messages d'erreur.
   *
   * @param string|array
   * @return HtmlFormElement
   */
  public function setAlert( $alert )
  {
    if( ! is_string($alert) and ! is_array($alert) ) throw new InvalidArgumentException;

    $this->alert = $alert;

    return $this;
  }

  // }}}
  // {{{ setID()

  /**
   * Modifie l'identifiant unique.
   *
   * @param string
   * @return HtmlFormElement
   */
  public function setID( $id )
  {
    if( ! is_string($id) ) throw new InvalidArgumentException;

    $this->id = $id;

    return $this;
  }

  // }}}
  // {{{ setI18n()

  /**
   * Modifie l'identifiant unique.
   *
   * @param string
   * @return HtmlFormElement
   */
  public function setI18n( HtmlFormElement $element, $i18n )
  {
    if( $i18n instanceof HtmlFormI18n )
    {
      $this->i18n = $i18n;
      return $this;
    }

    if( ! is_string($i18n) ) throw new InvalidArgumentException;

    if( ! class_exists($class_name = $element->class.ucfirst($i18n).'I18n') )
      throw new BadMethodCallException(sprintf('Try to use an unexists i18n class: %s', $class_name));

    if( ! is_subclass_of($class_name,'HtmlFormI18n') )
      throw new BadMethodCallException(sprintf('The element class: %s isn\'t an child of the class: HtmlFormI18n', $class_name));

    $this->i18n = new $class_name( $element );

    return $this;
  }

  // }}}
  // {{{ setDefault()

  /**
   * Modifie le label du champ.
   *
   * @param string|array|boolean
   * @return HtmlFormElement
   */
  public function setDefault( $default )
  {
    if( ! is_string($default) and ! is_array($default) and ! is_bool($default) ) throw new InvalidArgumentException(sprintf('%s::%s() need a string or array or boolean for his 1st parameter',__CLASS__,__FUNCTION__));

    $this->default = $default;

    return $this;
  }

  // }}}
  // {{{ init()

  /**
   * Phase d'initialisation d'un champ.
   *
   * @param HtmlForm
   */
  protected function init( HtmlForm $form )
  {
    if( is_null($this->map) )
      $this->setMap( $this->name );
    if( is_null($this->label) )
      $this->setLabel( ucfirst($this->name) );
    if( is_null($this->alert) )
      $this->setAlert( 'Error on field: '.$this->label );
    if( is_null($this->id) )
      $this->setID( substr(md5($this->name),0,4) );
    $this->setRequired($this->required);
  }

  // }}}
  // {{{ getValue()

  protected function getValue()
  {
    if( $this->form->method == 'get' and isset($_GET[$this->name]) )
      return $_GET[$this->name];
    elseif( $this->form->method == 'post' and isset($_POST[$this->name]) )
      return $_POST[$this->name];
    elseif( isset($_REQUEST[$this->name]) )
      return $_REQUEST[$this->name];
  }

  // }}}
  // {{{ stringifize()

  /**
   * Convertir tout tableau en cha�ne de caract�re en prenant le premier element uniquement.
   *
   * Permet de contrequarer les envoies de param�tres en utilisant la synataxe &var[]=value.
   *
   * @return string|null
   */
  static protected function stringifize( $value )
  {
    if( is_array($value) and $value )
      return self::stringifize( array_shift($value) );
    elseif( is_string($value) )
      return $value;
    else
      return null;
  }

  // }}}
}

/**
 * Classe d'un champ de type texte.
 */
class HtmlFormText extends HtmlFormElement
{
  // {{{ init()

  /**
   * Initialise un element de type text.
   *
   * V�rifie et corrige le faite que la valeur de l'element ne peut pas �tre un tableau.
   *
   * @param HtmlForm
   */
  protected function init( HtmlForm $form )
  {
    parent::init( $form );

    if( is_array($this->value) and $this->value )
      $this->value = array_shift($this->value);
    elseif( is_array($this->value) )
      $this->value = null;      
  }

  // }}}
  // {{{ getValue()

  protected function getValue()
  {
    return self::stringifize( parent::getValue() );
  }

  // }}}
}

/**
 * Classe abstraite de champ contenant des valeurs pr�definies.
 */
abstract class HtmlFormValuesContainer extends HtmlFormElement implements ArrayAccess, Iterator
{
  // {{{ $values

  /**
   * La listes de valeurs possibles.
   *
   * @var array
   */
  protected $values = array();

  // }}}
  // {{{ setValues()

  /**
   * Modifie la liste des valeurs.
   *
   * @param array La liste des valeurs
   * @return HtmlFormElement
   */
  public function setValues( $values )
  {
    if( ! is_array($values) )
    {
      if( ! $this->values )
        $this->values[1] = $values;
      else
        $this->values[] = $values;

      $args = func_get_args();
      if( count($args) > 1 )
      {
        array_shift($args);
        call_user_func_array( array($this,__FUNCTION__), $args );
      }
      return $this;
    }
    else
    {
      $this->values = $values;

      return $this;
    }
  }

  // }}}
  // {{{ current()

  /**
   * @ignore
   */
  public function current()
  {
    return current($this->values);
  }

  // }}}
  // {{{ next()

  /**
   * @ignore
   */
  public function next()
  {
    return next($this->values);
  }

  // }}}
  // {{{ key()

  /**
   * @ignore
   */
  public function key()
  {
    return key($this->values);
  }

  // }}}
  // {{{ rewind()

  /**
   * @ignore
   */
  public function rewind()
  {
    return reset($this->values);
  }

  // }}}
  // {{{ valid()

  /**
   * @ignore
   */
  public function valid()
  {
    return (bool)current($this->values);
  }

  // }}}
  // {{{ offsetExists()

  /**
   * @ignore
   */
  public function offsetExists( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    return isset($this->values[$offset]);
  }

  // }}}
  // {{{ offsetGet()

  /**
   * @ignore
   */
  public function offsetGet( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    if( ! isset($this->values[$offset]) ) throw new OutOfBoundsException(sprintf('Try to acces to an undefined index: %.',$offset));

    return $this->values[$offset];
  }

  // }}}
  // {{{ offsetSet()

  /**
   * @ignore
   */
  public function offsetSet( $offset, $value )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;
    if( ! $value instanceof HtmlFormElement ) throw new InvalidArgumentException;

    $this->values[$offset] = $value;
  }

  // }}}
  // {{{ offsetUnset()

  /**
   * @ignore
   */
  public function offsetUnset( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    if( ! isset($this->values[$offset]) ) throw new OutOfBoundsException(sprintf('Try to acces to an undefined index: %.',$offset));

    unset( $this->values[$offset] );
  }

  // }}}
  // {{{ init()

  /**
   * Initialise un element de type text.
   *
   * V�rifie et corrige le faite que la valeur de l'element ne peut pas �tre un tableau.
   */
  protected function init( HtmlForm $form )
  {
    parent::init( $form );

    if( is_array($this->value) and $this->value )
      $this->value = array_shift($this->value);
    elseif( is_array($this->value) )
      $this->value = null;

    array_push( $this->check, array(__CLASS__,'checkValues') );
  }

  // }}}
  // {{{ checkValues()

  /**
   * Fonction de callback.
   *
   * V�rifie si la valeur envoy� par client fait parti de la listes des valeurs possibles.
   *
   * @param HtmlFormElement
   * @param HtmlForm
   * @return boolean
   */
  static protected function checkValues( HtmlFormElement $element, HtmlForm $form )
  {
    if( ! is_array($element->values) ) throw new UnexpectedValueException(sprintf('%s::%s must be an array.',get_class($element),'$values'));

    return ! isset($element[$element->value]);
  }

  // }}}
}

/**
 * Classe d'un champ de type select.
 */
class HtmlFormDropdown extends HtmlFormValuesContainer
{
  // {{{ $choice

  /**
   * Le premier element de la liste.
   *
   * @var string|false
   */
  protected $choice = '-- select --';

  // }}}
  // {{{ setChoice()

  /**
   * Modifie la premi�re valeur.
   *
   * @param string
   * @return HtmlFormSelect
   */
  public function setChoice( $choice )
  {
    if( ! is_string($choice) ) throw new InvalidArgumentException;

    $this->choice = $choice;

    return $this;
  }

  // }}}
  // {{{ getValue()

  protected function getValue()
  {
    return self::stringifize( parent::getValue() );
  }

  // }}}
}

/**
 * Classe de champ de type button.
 */
class HtmlFormButton extends HtmlFormElement
{
  // {{{ getValue()

  protected function getValue()
  {
    return self::stringifize( parent::getValue() );
  }

  // }}}
}

/**
 * Classe de champ de type radio.
 */
class HtmlFormRadio extends HtmlFormValuesContainer
{
  // {{{ getValue()

  protected function getValue()
  {
    return self::stringifize( parent::getValue() );
  }

  // }}}
}

/**
 * Alias pour HtmlFormRadio.
 */
class HtmlFormRadios extends HtmlFormRadio
{
}

/**
 * Classe de champ de type checkbox.
 */
class HtmlFormCheckbox extends HtmlFormElement
{
  // {{{ getValue()

  protected function getValue()
  {
    return self::stringifize( parent::getValue() );
  }

  // }}}
}

/**
 * Classe de groupe de champ de type checkbox.
 */
class HtmlFormCheckboxs extends HtmlFormValuesContainer
{
}

/**
 * Classe de champ de type checkbox - subscribe
 */
class HtmlFormSubscribe extends HtmlFormCheckbox
{
  // {{{ $name

  protected $name = 'subscribe';

  // }}}
  // {{{ $email

  /**
   * Une r�f�rence vers l'�l�ment email.
   *
   * @var HtmlFormEmail
   */
  protected $email = null;

  // }}}
  // {{{ setEmail()

  /**
   * Modifie l'instance de l'�l�ment email.
   *
   * @param string|HtmlFormEmail
   * @return HtmlFormElement
   */
  public function setEmail( $email )
  {
    if( ! $email instanceof HtmlFormEmail ) throw new InvalidArgumentException(sprintf('%s::%s() need a HtmlFormEmail instance for his 1st parameter.',__CLASS__,__FUNCTION__));

    $this->email = $email;

    return $this;
  }

  // }}}
  // {{{ hie()

  /**
   * Instancie un �l�ment
   *
   * @param HtmlForm L'instance du formulaire
   * @param string Le nom de la classe � instancier
   * @param string|null Le nom d'un l'�l�ment email pr�cedament ajouter
   * @return HtmlFormElement
   */
  static public function hie( HtmlForm $form, $class_name )
  {
    $element = parent::hie( $form, $class_name );

    if( func_num_args() > 2 ) $email = func_get_arg(2); else $email = null;

    if( ! is_string($email) and ! isset($form[$email]) and ! is_null($email) ) throw new InvalidArgumentException(sprintf('%::%s() need the name of an email element already added to the form for his 3rd parameter.',__CLASS__,__FUNCTION__));

    if( is_string($email) )
      $element->setEmail($form[$email]);

    return $element;
  }

  // }}}
  // {{{ init()

  protected function init( HtmlForm $form)
  {
    parent::init( $form );

    array_push( $this->check, array(__CLASS__,'checkEmail') );

    if( $this->value === '' )
      $this->value = '0';
  }

  // }}}
  // {{{ checkEmail()

  /**
   * Fonction de callback.
   *
   * V�rifie si la l'adresse email � �t� renseign�
   *
   * @param HtmlFormElement
   * @param HtmlForm
   * @return boolean
   */
  static protected function checkEmail( HtmlFormElement $element, HtmlForm $form )
  {
    if( $element->email instanceof HtmlFormEmail and $element->value==='1' )
    {
        $element->email->required = $element->required;
        if( $element->email->ifError( $element->email->value, $form ) )
          return true;
    }

    return false;
  }


  // }}}
  // {{{ __get()

  public function __get( $property )
  {
    if( ! is_string($property) ) throw new InvalidArgumentException(sprintf('%s::%s() need a string for his 1st parametre',__CLASS__,__FUNCTION__));

    if( $property === 'error' )
      return false;
    elseif( $property === 'required' )
      return false;

    return parent::__get( $property );
  }

  // }}}
}

/**
 * Classe de champ de type texte - email.
 */
class HtmlFormEmail extends HtmlFormText
{
  // {{{ $name

  protected $name = 'email';

  // }}}
  // {{{ $map

  protected $map = 'email';

  // }}}
  // {{{ $label

  protected $label = 'Email';

  // }}}
  // {{{ $check

  protected $check = array(
    '/^[a-z0-9._%-]+@[a-z0-9._%-]+\\.[a-z]{2,4}$/i'
    );

  // }}}
}

/**
 * Classe de champ de type button - submit
 */
class HtmlFormSubmit extends HtmlFormButton
{
  // {{{ $map

  protected $map = null;

  // }}}
  // {{{ $label

  protected $label = 'Submit';

  // }}}
  // {{{ $required

  protected $required = 'Form must be submited';

  // }}}
  // {{{ init()

  protected function init( HtmlForm $form )
  {
    parent::init( $form );

    $this->name = $form->name;
  }

  // }}}
  // {{{ __get()

  public function __get( $property )
  {
    if( ! is_string($property) ) throw new InvalidArgumentException(sprintf('%s::%s() need a string for his 1st parametre',__CLASS__,__FUNCTION__));

    if( $property === 'value' )
      return @$_REQUEST[$this->name];

    return parent::__get( $property );
  }

  // }}}
}

/**
 * Classe de champ de type select - country.
 */
class HtmlFormCountry extends HtmlFormDropdown
{
  // {{{ $name

  protected $name = 'Country';

  // }}}
  // {{{ $map

  protected $map = 'country';

  // }}}
  // {{{ $label

  protected $label = 'Country';

  // }}}
  // {{{ $values



  // }}}
  // {{{ $check

  protected $check = array(
    '/(?:[A-Z]{2}|--)$/' );

  // }}}
  // {{{ $choice

  protected $choice = '-- Select a country --';

  // }}}
  // {{{ init()

  protected function init( HtmlForm $form )
  {
    parent::init( $form );

    $this->i18n = new HtmlFormCountryEnglishI18n( $this );
  }

  // }}}
  // {{{ current()

  /**
   * @ignore
   */
  public function current()
  {
    return $this->i18n->current();
  }

  // }}}
  // {{{ next()

  /**
   * @ignore
   */
  public function next()
  {
    return $this->i18n->next();
  }

  // }}}
  // {{{ key()

  /**
   * @ignore
   */
  public function key()
  {
    return $this->i18n->key();
  }

  // }}}
  // {{{ rewind()

  /**
   * @ignore
   */
  public function rewind()
  {
    return $this->i18n->rewind();
  }

  // }}}
  // {{{ valid()

  /**
   * @ignore
   */
  public function valid()
  {
    return $this->i18n->valid();
  }

  // }}}
  // {{{ offsetExists()

  /**
   * @ignore
   */
  public function offsetExists( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    return isset($this->i18n[$offset]);
  }

  // }}}
  // {{{ offsetGet()

  /**
   * @ignore
   */
  public function offsetGet( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    if( ! isset($this->i18n[$offset]) ) throw new OutOfBoundsException(sprintf('Try to acces to an undefined index: %.',$offset));

    return $this->i18n[$offset];
  }

  // }}}
  // {{{ offsetSet()

  /**
   * @ignore
   */
  public function offsetSet( $offset, $value )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;
    if( ! $value instanceof HtmlFormElement ) throw new InvalidArgumentException;

    $this->i18n[$offset] = $value;
  }

  // }}}
  // {{{ offsetUnset()

  /**
   * @ignore
   */
  public function offsetUnset( $offset )
  {
    if( ! is_string($offset) ) throw new InvalidArgumentException;

    if( ! isset($this->i18n[$offset]) ) throw new OutOfBoundsException(sprintf('Try to acces to an undefined index: %.',$offset));

    unset( $this->i18n[$offset] );
  }

  // }}}
}

/**
 * Classe de cha�ne de traduction anglaise pour les pays
 */
class HtmlFormCountryEnglishI18n extends HtmlFormI18n
{
  // {{{ $strings

  protected $strings = array(
'AF'=>"Afghanistan",
'AL'=>"Albania",
'DZ'=>"Algeria",
'AS'=>"American Samoa",
'AD'=>"Andorra",
'AG'=>"Angola",
'AI'=>"Anguilla",
'AG'=>"Antigua & Barbuda",
'AR'=>"Argentina",
'AA'=>"Armenia",
'AW'=>"Aruba",
'AU'=>"Australia",
'AT'=>"Austria",
'AZ'=>"Azerbaijan",
'BS'=>"Bahamas",
'BH'=>"Bahrain",
'BD'=>"Bangladesh",
'BB'=>"Barbados",
'BY'=>"Belarus",
'BE'=>"Belgium",
'BZ'=>"Belize",
'BJ'=>"Benin",
'BM'=>"Bermuda",
'BT'=>"Bhutan",
'BO'=>"Bolivia",
'BL'=>"Bonaire",
'BA'=>"Bosnia & Herzegovina",
'BW'=>"Botswana",
'BR'=>"Brazil",
'BC'=>"British Indian Ocean Ter",
'BN'=>"Brunei",
'BG'=>"Bulgaria",
'BF'=>"Burkina Faso",
'BI'=>"Burundi",
'KH'=>"Cambodia",
'CM'=>"Cameroon",
'CA'=>"Canada",
'IC'=>"Canary Islands",
'CV'=>"Cape Verde",
'KY'=>"Cayman Islands",
'CF'=>"Central African Republic",
'TD'=>"Chad",
'CD'=>"Channel Islands",
'CL'=>"Chile",
'CN'=>"China",
'CI'=>"Christmas Island",
'CS'=>"Cocos Island",
'CO'=>"Colombia",
'CC'=>"Comoros",
'CG'=>"Congo",
'CK'=>"Cook Islands",
'CR'=>"Costa Rica",
'CT'=>"Cote D'Ivoire",
'HR'=>"Croatia",
'CU'=>"Cuba",
'CB'=>"Curacao",
'CY'=>"Cyprus",
'CZ'=>"Czech Republic",
'DK'=>"Denmark",
'DJ'=>"Djibouti",
'DM'=>"Dominica",
'DO'=>"Dominican Republic",
'TM'=>"East Timor",
'EC'=>"Ecuador",
'EG'=>"Egypt",
'SV'=>"El Salvador",
'GQ'=>"Equatorial Guinea",
'ER'=>"Eritrea",
'EE'=>"Estonia",
'ET'=>"Ethiopia",
'FA'=>"Falkland Islands",
'FO'=>"Faroe Islands",
'FJ'=>"Fiji",
'FI'=>"Finland",
'FR'=>"France",
'GF'=>"French Guiana",
'PF'=>"French Polynesia",
'FS'=>"French Southern Ter",
'GA'=>"Gabon",
'GM'=>"Gambia",
'GE'=>"Georgia",
'DE'=>"Germany",
'GH'=>"Ghana",
'GI'=>"Gibraltar",
'GB'=>"Great Britain",
'GR'=>"Greece",
'GL'=>"Greenland",
'GD'=>"Grenada",
'GP'=>"Guadeloupe",
'GU'=>"Guam",
'GT'=>"Guatemala",
'GN'=>"Guinea",
'GY'=>"Guyana",
'HT'=>"Haiti",
'HW'=>"Hawaii",
'HN'=>"Honduras",
'HK'=>"Hong Kong",
'HU'=>"Hungary",
'IS'=>"Iceland",
'IN'=>"India",
'ID'=>"Indonesia",
'IA'=>"Iran",
'IQ'=>"Iraq",
'IR'=>"Ireland",
'IM'=>"Isle of Man",
'IL'=>"Israel",
'IT'=>"Italy",
'JM'=>"Jamaica",
'JP'=>"Japan",
'JO'=>"Jordan",
'KZ'=>"Kazakhstan",
'KE'=>"Kenya",
'KI'=>"Kiribati",
'NK'=>"Korea North",
'KS'=>"Korea South",
'KW'=>"Kuwait",
'KG'=>"Kyrgyzstan",
'LA'=>"Laos",
'LV'=>"Latvia",
'LB'=>"Lebanon",
'LS'=>"Lesotho",
'LR'=>"Liberia",
'LY'=>"Libya",
'LI'=>"Liechtenstein",
'LT'=>"Lithuania",
'LU'=>"Luxembourg",
'MO'=>"Macau",
'MK'=>"Macedonia",
'MG'=>"Madagascar",
'MY'=>"Malaysia",
'MW'=>"Malawi",
'MV'=>"Maldives",
'ML'=>"Mali",
'MT'=>"Malta",
'MH'=>"Marshall Islands",
'MQ'=>"Martinique",
'MR'=>"Mauritania",
'MU'=>"Mauritius",
'ME'=>"Mayotte",
'MX'=>"Mexico",
'MI'=>"Midway Islands",
'MD'=>"Moldova",
'MC'=>"Monaco",
'MN'=>"Mongolia",
'MS'=>"Montserrat",
'MA'=>"Morocco",
'MZ'=>"Mozambique",
'MM'=>"Myanmar",
'NA'=>"Nambia",
'NU'=>"Nauru",
'NP'=>"Nepal",
'AN'=>"Netherland Antilles",
'NL'=>"Netherlands",
'NV'=>"Nevis",
'NC'=>"New Caledonia",
'NZ'=>"New Zealand",
'NI'=>"Nicaragua",
'NE'=>"Niger",
'NG'=>"Nigeria",
'NW'=>"Niue",
'NF'=>"Norfolk Island",
'NO'=>"Norway",
'OM'=>"Oman",
'PK'=>"Pakistan",
'PW'=>"Palau Island",
'PS'=>"Palestine",
'PA'=>"Panama",
'PG'=>"Papua New Guinea",
'PY'=>"Paraguay",
'PE'=>"Peru",
'PH'=>"Philippines",
'PO'=>"Pitcairn Island",
'PL'=>"Poland",
'PT'=>"Portugal",
'PR'=>"Puerto Rico",
'QA'=>"Qatar",
'RE'=>"Reunion",
'RO'=>"Romania",
'RU'=>"Russia",
'RW'=>"Rwanda",
'NT'=>"St Barthelemy",
'EU'=>"St Eustatius",
'HE'=>"St Helena",
'KN'=>"St Kitts-Nevis",
'LC'=>"St Lucia",
'MB'=>"St Maarten",
'PM'=>"St Pierre & Miquelon",
'VC'=>"St Vincent & Grenadines",
'SP'=>"Saipan",
'SO'=>"Samoa",
'AS'=>"Samoa American",
'SM'=>"San Marino",
'ST'=>"Sao Tome & Principe",
'SA'=>"Saudi Arabia",
'SN'=>"Senegal",
'SC'=>"Seychelles",
'SS'=>"Serbia & Montenegro",
'SL'=>"Sierra Leone",
'SG'=>"Singapore",
'SK'=>"Slovakia",
'SI'=>"Slovenia",
'SB'=>"Solomon Islands",
'OI'=>"Somalia",
'ZA'=>"South Africa",
'ES'=>"Spain",
'LK'=>"Sri Lanka",
'SD'=>"Sudan",
'SR'=>"Suriname",
'SZ'=>"Swaziland",
'SE'=>"Sweden",
'CH'=>"Switzerland",
'SY'=>"Syria",
'TA'=>"Tahiti",
'TW'=>"Taiwan",
'TJ'=>"Tajikistan",
'TZ'=>"Tanzania",
'TH'=>"Thailand",
'TG'=>"Togo",
'TK'=>"Tokelau",
'TO'=>"Tonga",
'TT'=>"Trinidad & Tobago",
'TN'=>"Tunisia",
'TR'=>"Turkey",
'TU'=>"Turkmenistan",
'TC'=>"Turks & Caicos Is",
'TV'=>"Tuvalu",
'UG'=>"Uganda",
'UA'=>"Ukraine",
'AE'=>"United Arab Emirates",
'GB'=>"United Kingdom",
'US'=>"United States of America",
'UY'=>"Uruguay",
'UZ'=>"Uzbekistan",
'VU'=>"Vanuatu",
'VS'=>"Vatican City State",
'VE'=>"Venezuela",
'VN'=>"Vietnam",
'VB'=>"Virgin Islands (Brit)",
'VA'=>"Virgin Islands (USA)",
'WK'=>"Wake Island",
'WF'=>"Wallis & Futana Is",
'YE'=>"Yemen",
'ZR'=>"Zaire",
'ZM'=>"Zambia",
'ZW'=>"Zimbabwe",
'--'=>"-- Other --"
);

  // }}}
}

/**
 * Classs de cha�ne de traduction fran�aise pour les pays
 */
class HtmlFormCountryFrenchI18n extends HtmlFormI18n
{
  // {{{ $strings

  protected $strings = array(
'AF' => 'Afghanistan',
'ZA' => 'Afrique du Sud',
'AL' => 'Albanie',
'DZ' => 'Alg&eacute;rie',
'DE' => 'Allemagne',
'AD' => 'Andorre',
'AO' => 'Angola',
'AI' => 'Anguilla',
'AQ' => 'Antarctique',
'AG' => 'Antigua-et-Barbuda',
'AN' => 'Antilles n&eacute;erlandaises',
'SA' => 'Arabie Saoudite',
'AR' => 'Argentine',
'AM' => 'Arm&eacute;nie',
'AW' => 'Aruba',
'AU' => 'Australie',
'AT' => 'Autriche',
'AZ' => 'Azerba&iuml;djan',
'BS' => 'Bahamas',
'BH' => 'Bahre&iuml;n',
'BD' => 'Bangladesh',
'BB' => 'Barbade (la)',
'BE' => 'Belgique',
'BZ' => 'Belize',
'BJ' => 'B&eacute;nin',
'BM' => 'Bermudes',
'BT' => 'Bhoutan',
'BY' => 'Bi&eacute;lorussie',
'BO' => 'Bolivie',
'BA' => 'Bosnie et Herz&eacute;govine',
'BW' => 'Botswana',
'BR' => 'Br&eacute;sil',
'BN' => 'Brunei',
'BG' => 'Bulgarie',
'BF' => 'Burkina-Faso',
'BI' => 'Burundi',
'KH' => 'Cambodge',
'CM' => 'Cameroun',
'CA' => 'Canada',
'CV' => 'Cap-Vert',
'CL' => 'Chili',
'CN' => 'Chine',
'CY' => 'Chypre',
'CO' => 'Colombie',
'KM' => 'Comores',
'CG' => 'Congo',
'CD' => 'Congo, R&eacute;publique du',
'KR' => 'Cor&eacute;e',
'KP' => 'Cor&eacute;e du Nord',
'CR' => 'Costa Rica',
'CI' => 'C&ocirc;te D\'Ivoire',
'HR' => 'Croatie',
'CU' => 'Cuba',
'DK' => 'Danemark',
'UM' => 'D&eacute;pendances am&eacute;ricaines du Pacifique',
'DJ' => 'Djibouti',
'DM' => 'Dominique (la)',
'EG' => '&Eacute;gypte',
'AE' => '&Eacute;mirats Arabes Unis',
'EC' => '&Eacute;quateur (R&eacute;publique de l\')',
'ER' => '&Eacute;rythr&eacute;e',
'ES' => 'Espagne',
'EE' => 'Estonie',
'VA' => '&Eacute;tat de la cit&eacute; du Vatican',
'US' => '&Eacute;tats-Unis',
'ET' => '&Eacute;thiopie',
'RU' => 'F&eacute;d&eacute;ration de Russie',
'FJ' => 'Fidji',
'FI' => 'Finlande',
'FR' => 'France',
'GA' => 'Gabon',
'GM' => 'Gambie',
'GE' => 'G&eacute;orgie',
'GS' => 'G&eacute;orgie du Sud et Sandwich du Sud (&Icirc;Ies)',
'GH' => 'Ghana',
'GI' => 'Gibraltar',
'GR' => 'Gr&egrave;ce',
'GD' => 'Grenade',
'GL' => 'Groenland',
'GP' => 'Guadeloupe (France DOM-TOM)',
'GU' => 'Guam',
'GT' => 'Guatemala',
'GN' => 'Guin&eacute;e',
'GQ' => 'Guin&eacute;e &Eacute;quatoriale',
'GW' => 'Guin&eacute;e-Bissau',
'GY' => 'Guyane',
'GF' => 'Guyane fran&ccedil;aise',
'HT' => 'Ha&iuml;ti',
'HN' => 'Honduras (le)',
'HK' => 'Hong Kong',
'HU' => 'Hongrie',
'CX' => '&Icirc;le Christmas',
'NF' => '&Icirc;le de Norfolk',
'MU' => '&Icirc;le Maurice',
'SJ' => '&Icirc;le Svalbard et Jan Mayen',
'BV' => '&Icirc;les Bouvet',
'KY' => '&Icirc;les Ca&iuml;mans',
'CC' => '&Icirc;les Cocos-Keeling',
'CK' => '&Icirc;les Cook',
'FO' => '&Icirc;les F&eacute;ro&eacute;',
'HM' => '&Icirc;les Heard et Mc Donald',
'FK' => '&Icirc;les Malouines',
'MH' => '&Icirc;les Marshall',
'SB' => '&Icirc;les Salomon',
'TK' => '&Icirc;les Tokelau',
'TC' => '&Icirc;les Turks et Ca&iuml;cos',
'VI' => '&Icirc;les Vierges am&eacute;ricaines',
'VG' => '&Icirc;les Vierges britanniques',
'IN' => 'Inde',
'ID' => 'Indon&eacute;sie',
'IQ' => 'Irak',
'IR' => 'Iran',
'IE' => 'Irlande',
'IS' => 'Islande',
'IL' => 'Isra&euml;l',
'IT' => 'Italie',
'LY' => 'Jamahiriya arabe libyenne (Lybie)',
'JM' => 'Jama&iuml;que',
'JP' => 'Japon',
'JO' => 'Jordanie',
'KZ' => 'Kazakhstan',
'KE' => 'Kenya',
'KG' => 'Kirghizistan',
'KI' => 'Kiribati',
'KW' => 'Kowe&iuml;t',
'LS' => 'Lesotho',
'LV' => 'Lettonie',
'LB' => 'Liban',
'LR' => 'Liberia',
'LI' => 'Liechtenstein',
'LT' => 'Lituanie',
'LU' => 'Luxembourg',
'MO' => 'Macao',
'MK' => 'Mac&eacute;doine, Ex-R&eacute;publique yougoslave de',
'MG' => 'Madagascar',
'MY' => 'Malaisie',
'MW' => 'Malawi',
'MV' => 'Maldives',
'ML' => 'Mali',
'MT' => 'Malte',
'MP' => 'Mariannes du Nord (&Icirc;les du Commonwealth)',
'MA' => 'Maroc',
'MQ' => 'Martinique (France DOM-TOM)',
'MR' => 'Mauritanie',
'YT' => 'Mayotte',
'MX' => 'Mexique',
'FM' => 'Micron&eacute;sie',
'MD' => 'Moldavie',
'MC' => 'Monaco',
'MN' => 'Mongolie',
'MS' => 'Montserrat',
'MZ' => 'Mozambique',
'MM' => 'Myanmar (Union de)',
'NA' => 'Namibie',
'NR' => 'Nauru (R&eacute;publique de)',
'NP' => 'N&eacute;pal',
'NI' => 'Nicaragua',
'NE' => 'Niger',
'NG' => 'Nig&eacute;ria',
'NU' => 'Niue',
'NO' => 'Norv&egrave;ge',
'NC' => 'Nouvelle Cal&eacute;donie',
'NZ' => 'Nouvelle Z&eacute;lande',
'OM' => 'Oman',
'UG' => 'Ouganda',
'UZ' => 'Ouzb&eacute;kist&auml;n',
'PK' => 'Pakistan',
'PW' => 'Palau',
'PA' => 'Panama',
'PG' => 'Papouasie Nouvelle-Guin&eacute;e',
'PY' => 'Paraguay',
'NL' => 'Pays-Bas',
'PE' => 'P&eacute;rou',
'PH' => 'Philippines',
'PN' => 'Pitcairn (&Icirc;les)',
'PL' => 'Pologne',
'PF' => 'Polyn&eacute;sie fran&ccedil;aise (DOM-TOM)',
'PR' => 'Porto Rico',
'PT' => 'Portugal',
'QA' => 'Qatar',
'SY' => 'R&eacute;publique arabe syrienne',
'CF' => 'R&eacute;publique Centrafricaine',
'LA' => 'R&eacute;publique d&eacute;mocratique populaire du Laos',
'DO' => 'R&eacute;publique Dominicaine',
'CZ' => 'R&eacute;publique tch&egrave;que',
'RE' => 'R&eacute;union (&Icirc;le de la)',
'RO' => 'Roumanie',
'UK' => 'Royaume-Uni',
'RW' => 'Rwanda',
'SH' => 'Sainte H&eacute;l&egrave;ne',
'LC' => 'Saint-Lucie',
'SM' => 'Saint-Marin',
'PM' => 'Saint-Pierre-et-Miquelon (France DOM-TOM)',
'VC' => 'Saint-Vincent et les Grenadines',
'SV' => 'Salvador',
'WS' => 'Samoa',
'AS' => 'Samoa am&eacute;ricaines',
'ST' => 'S&acirc;o Tom&eacute; et Prince',
'SN' => 'S&eacute;n&eacute;gal',
'SC' => 'Seychelles',
'SL' => 'Sierra Leone',
'SG' => 'Singapour',
'SK' => 'Slovaquie',
'SI' => 'Slov&eacute;nie',
'SO' => 'Somalie',
'SD' => 'Soudan',
'LK' => 'Sri Lanka',
'KN' => 'St Christopher et Nevis (&Icirc;les)',
'SE' => 'Su&egrave;de',
'CH' => 'Suisse',
'SR' => 'Suriname',
'SZ' => 'Swaziland',
'TW' => 'Taiwan',
'TJ' => 'Tajikistan',
'TZ' => 'Tanzanie',
'TD' => 'Tchad',
'TF' => 'Terres Australes fran&ccedil;aises (DOM-TOM)',
'IO' => 'Territoires Britanniques de l\'oc&eacute;an Indien',
'TH' => 'Tha&iuml;lande',
'TP' => 'Timor oriental (partie orientale)',
'TG' => 'Togo',
'TO' => 'Tonga',
'TT' => 'Trinit&eacute;-et-Tobago',
'TN' => 'Tunisie',
'TM' => 'Turkm&eacute;nistan',
'TR' => 'Turquie',
'TV' => 'Tuvalu (&Icirc;les)',
'UA' => 'Ukraine',
'UY' => 'Uruguay',
'VU' => 'Vanuatu (R&eacute;publique de)',
'VE' => 'Venezuela',
'VN' => 'Vietnam',
'WF' => 'Wallis et Futuna',
'YE' => 'Y&eacute;men',
'YU' => 'Yougoslavie',
'ZM' => 'Zambie',
'ZW' => 'Zimbabwe',
'--' => '-- Autre --' );

  // }}}
  // {{{ current()

  public function current()
  {
    return html_entity_decode(current($this->strings));
  }

  // }}}
}

/**
 * @ignore
 */
if( ! class_exists('BadPropertyException') )
{
  class BadPropertyException extends LogicException
  {
  }
}

/**
 * Interface pour les decorateurs
 */
interface HtmlOutInterface
{
  // {{{ display()

  /**
   * Affiche le formulaire
   *
   * @param HtmlForm
   */
  static public function display( HtmlForm $form );

  // }}}
  // {{{ fetch()

  /**
   * Retourne le code HTML du formulaire
   *
   * @param HtmlForm
   */
  static public function fetch( HtmlForm $form );

  // }}}
}

/**
 * Decorateur pas d�fault
 */
final class HtmlOut implements HtmlOutInterface
{
  // {{{ display()

  static public function display( HtmlForm $form )
  {
    echo self::fetch( $form );
  }

  // }}}
  // {{{ fetch()

  static public function fetch( HtmlForm $form )
  {
    $form->doValid();

    $buffer = <<<HTML
<form name="{$form->name}" method="{$form->method}">

HTML;

    foreach( $form as $element )
    {
      $result = '';
      switch( true )
      {
      case $element instanceof HtmlFormText :
        $result = self::text( $element );
        break;
      case $element instanceof HtmlFormDropdown :
        $result = self::select( $element );
        break;
      case $element instanceof HtmlFormButton :
        $result = self::button( $element );
        break;
      case $element instanceof HtmlFormRadio :
        $result = self::radio( $element );
        break;
      case $element instanceof HtmlFormCheckbox :
        $result = self::checkbox( $element );
        break;
      }
      if( ! is_string($result) )
        throw new UnexpectedValueException( sprintf('%s::%s() must return a string',__CLASS__,$method_name) );
      $buffer .= $result;
    }

    $buffer .= <<<HTML
</form>

HTML;

    return $buffer;
  }

  // }}}
  // {{{ prepare_fetch()

  /**
   * Pr�pare quelques donn�es communes
   */
  static private function prepare_fetch( HtmlFormElement $element, &$alert, &$error )
  {
    if( is_string($element->error) )
      $alert = <<<HTML
    <div class="alert"><p>{$element->error}</p></div>

HTML;
    else
      $alert = '';

    if( $element->error )
      $error = ' error';
    else
      $error = '';
  }

  // }}}
  // {{{ text()

  static protected function text( HtmlFormText $e )
  {
    self::prepare_fetch( $e, $alert, $error );

    return <<<HTML
  <div class="element {$e->name}{$error}">
    <div class="label"><label for="{$e->id}">{$e->label}</label></div>
    <div class="field"><input id="{$e->id}" type="text" name="{$e->name}" value="{$e->html}" id="{$e->id}"/></div>
{$alert}  </div>

HTML;
  }

  // }}}
  // {{{ select()

  static protected function select( HtmlFormDropdown $e )
  {
    self::prepare_fetch( $e, $alert, $error );

    if( is_string($e->choice) )
      $options = <<<HTML
      <option value="">{$e->choice}</option>

HTML;
    else
      $options = '';

    $i = 0;
    foreach( $e as $key => $value )
    {
      $i += 1;
      if( is_array($e->value) )
        $selected = isset($e->value[$key]);
      elseif( is_string($e->value) )
        $selected = ($e->value==$key);
      else
        $selected = false;
      if( $selected )
        $selected = ' selected="selected"';
      $value = htmlspecialchars($value);
      $key = htmlspecialchars($key);
      $options .= <<<HTML
      <option value="{$key}" id="{$e->id}{$i}"{$selected}>{$value}</option>
HTML;
    }
    return <<<HTML
  <div class="element {$e->name}{$error}">
    <div class="label"><label>{$e->label}</label></div>
    <div class="field"><select name="{$e->name}" id="{$e->id}">
{$options}
    </select></div>
{$alert}  </div>

HTML;
  }

  // }}}
  // {{{ button()

  static protected function button( HtmlFormButton $e )
  {
    self::prepare_fetch( $e, $alert, $error );

    if( $e instanceof HtmlFormSubmit )
      $type = 'submit';
    else
      $type = 'button';
    return <<<HTML
  <div class="element {$e->name}{$error}">
    <div class="field"><input type="{$type}" name="{$e->name}" value="{$e->label}" /></div>
{$alert}  </div>

HTML;
  }

  // }}}
  // {{{ radio()

  static protected function radio( HtmlFormRadio $e )
  {
    self::prepare_fetch( $e, $alert, $error );

    $inputs = '';

    $i = 0;
    foreach( $e as $key => $value )
    {
      $key = htmlspecialchars($key);
      $value = htmlspecialchars($value);
      $i += 1;
      if( $e->value===$key )
        $checked = ' checked="checked"';
      else
        $checked = false;
      $inputs .= <<<HTML
      <input type="radio" name="{$e->name}" value="{$key}" id="{$e->id}{$i}"{$checked}><label for="{$e->id}{$i}">{$value}</label>
HTML;
    }
    return <<<HTML
  <div class="element {$e->name}{$error}">
    <div class="label"><label>{$e->label}</label></div>
    <div class="field">
{$inputs}
    </div>
{$alert}  </div>

HTML;
  }

  // }}}
  // {{{ checkbox

  static protected function checkbox( HtmlFormCheckbox $e )
  {
    self::prepare_fetch( $e, $alert, $error );

    if( $e->value==='1' )
      $checked = ' checked="checked';
    else
      $checked = false;

    return <<<HTML
  <div class="element {$e->name}{$error}">
    <div class="field"><input type="checkbox" name="{$e->name}" value="1" id="{$e->id}"{$checked}/><label for="{$e->id}">{$e->label}</label></div>
{$alert}  </div>

HTML;
  }

  // }}}
} 

?>
